package vn.iotstar.configs;

import org.sitemesh.builder.SiteMeshFilterBuilder;
import org.sitemesh.config.ConfigurableSiteMeshFilter;

public class SiteMeshFilter extends ConfigurableSiteMeshFilter {
    @Override
    protected void applyCustomConfiguration(SiteMeshFilterBuilder builder) {
        // 1. Cấu hình Decorator riêng biệt cho Admin và User
        builder.addDecoratorPath("/admin/*", "/admin.jsp")
               .addDecoratorPath("/products", "/web.jsp")
               .addDecoratorPath("/product/*", "/web.jsp")
               .addDecoratorPath("/*", "/web.jsp")
               
        // 2. Loại trừ các trang không cần Decorator
               .addExcludedPath("/")
               .addExcludedPath("/index.jsp")
               .addExcludedPath("/login")
               .addExcludedPath("/register")
               .addExcludedPath("/verify-otp")
               .addExcludedPath("/forgot-password")
               .addExcludedPath("/reset-password")
               .addExcludedPath("/image*")
               .addExcludedPath("/assets/*");
    }
}