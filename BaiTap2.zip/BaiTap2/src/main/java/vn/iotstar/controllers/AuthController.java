package vn.iotstar.controllers;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import vn.iotstar.entity.User;
import vn.iotstar.services.IUserService;
import vn.iotstar.services.impl.UserServiceImpl;

@WebServlet(urlPatterns = {"", "/", "/login", "/register", "/verify-otp", "/logout", "/forgot-password", "/reset-password"})
public class AuthController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private IUserService userService = new UserServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String url = req.getServletPath();
        
        // Khi người dùng vào trang chủ root ("" hoặc "/") hoặc /login
        if (url.equals("") || url.equals("/") || url.equals("/login")) {
            req.getRequestDispatcher("/views/login.jsp").forward(req, resp);
        } else if (url.equals("/register")) {
            req.getRequestDispatcher("/views/register.jsp").forward(req, resp);
        } else if (url.equals("/verify-otp")) {
            req.getRequestDispatcher("/views/verify-otp.jsp").forward(req, resp);
        } else if (url.equals("/logout")) {
            HttpSession session = req.getSession();
            session.invalidate();
            resp.sendRedirect(req.getContextPath() + "/login");
        } else if (url.equals("/forgot-password")) {
            req.getRequestDispatcher("/views/forgot-password.jsp").forward(req, resp);
        } else if (url.equals("/reset-password")) {
            req.getRequestDispatcher("/views/reset-password.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String url = req.getServletPath();

        if (url.equals("/register")) {
            String username = req.getParameter("username");
            String email = req.getParameter("email");
            String password = req.getParameter("password");
            String fullname = req.getParameter("fullname");

            boolean success = userService.register(username, email, password, fullname);
            if (success) {
                req.setAttribute("email", email);
                req.getRequestDispatcher("/views/verify-otp.jsp").forward(req, resp);
            } else {
                req.setAttribute("error", "Username hoặc Email đã tồn tại!");
                req.getRequestDispatcher("/views/register.jsp").forward(req, resp);
            }
        } else if (url.equals("/verify-otp")) {
            String email = req.getParameter("email");
            String otp = req.getParameter("otp");

            if (userService.verifyOTP(email, otp)) {
                req.setAttribute("message", "Kích hoạt tài khoản thành công! Hãy đăng nhập.");
                req.getRequestDispatcher("/views/login.jsp").forward(req, resp);
            } else {
                req.setAttribute("email", email);
                req.setAttribute("error", "Mã OTP không đúng hoặc đã hết hạn!");
                req.getRequestDispatcher("/views/verify-otp.jsp").forward(req, resp);
            }
        } else if (url.equals("/login")) {
            String username = req.getParameter("username");
            String password = req.getParameter("password");

            User user = userService.login(username, password);
            if (user != null) {
                HttpSession session = req.getSession();
                session.setAttribute("account", user);
                
                // KIỂM TRA PHÂN QUYỀN ĐIỀU HƯỚNG TẠI ĐÂY
                // Nếu roleid = 1 là Admin -> Vào trang Admin
                // Nếu không phải Admin (User/Role khác) -> Vào trang User
                if (user.getRoleid() == 1) {
                    resp.sendRedirect(req.getContextPath() + "/admin/categories");
                } else {
                    resp.sendRedirect(req.getContextPath() + "/products");
                }
            } else {
                req.setAttribute("error", "Sai tài khoản, mật khẩu hoặc tài khoản chưa kích hoạt!");
                req.getRequestDispatcher("/views/login.jsp").forward(req, resp);
            }
        } else if (url.equals("/forgot-password")) {
            String email = req.getParameter("email");
            if (userService.sendForgotPasswordOTP(email)) {
                req.setAttribute("email", email);
                req.getRequestDispatcher("/views/reset-password.jsp").forward(req, resp);
            } else {
                req.setAttribute("error", "Email không tồn tại trong hệ thống!");
                req.getRequestDispatcher("/views/forgot-password.jsp").forward(req, resp);
            }
        } else if (url.equals("/reset-password")) {
            String email = req.getParameter("email");
            String otp = req.getParameter("otp");
            String newPassword = req.getParameter("newPassword");

            if (userService.resetPassword(email, otp, newPassword)) {
                req.setAttribute("message", "Đổi mật khẩu thành công! Hãy đăng nhập lại.");
                req.getRequestDispatcher("/views/login.jsp").forward(req, resp);
            } else {
                req.setAttribute("email", email);
                req.setAttribute("error", "Mã OTP không đúng hoặc đã hết hạn!");
                req.getRequestDispatcher("/views/reset-password.jsp").forward(req, resp);
            }
        }
    }
}