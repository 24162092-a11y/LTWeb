package vn.iotstar.controllers;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import vn.iotstar.entity.Cart;
import vn.iotstar.entity.User;
import vn.iotstar.services.ICartService;
import vn.iotstar.services.impl.CartServiceImpl;

@WebServlet(urlPatterns = {"/cart", "/cart/add", "/cart/update", "/cart/remove", "/cart/clear", "/cart/checkout"})
public class CartController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private ICartService cartService = new CartServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        processRequest(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        processRequest(req, resp);
    }

    private void processRequest(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");

        HttpSession session = req.getSession();
        
        // 1. Kiểm tra session đăng nhập linh hoạt (bắt cả "account" lẫn "user")
        User user = (User) session.getAttribute("account");
        if (user == null) {
            user = (User) session.getAttribute("user");
        }
        
        if (user == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        // Lấy servletPath chính xác (ví dụ: "/cart/add", "/cart") thay vì req.getRequestURI()
        String path = req.getServletPath();

        // 2. THÊM SẢN PHẨM VÀO GIỎ HÀNG
        if ("/cart/add".equals(path)) {
            String idParam = req.getParameter("productId");
            if (idParam == null || idParam.trim().isEmpty()) {
                idParam = req.getParameter("id");
            }

            // Fallback: Tự lấy ID từ URL Referer nếu Form bị mất value
            if (idParam == null || idParam.trim().isEmpty()) {
                String referer = req.getHeader("referer");
                if (referer != null && referer.contains("id=")) {
                    idParam = referer.substring(referer.lastIndexOf("id=") + 3);
                    if (idParam.contains("&")) {
                        idParam = idParam.substring(0, idParam.indexOf("&"));
                    }
                }
            }

            String quantityParam = req.getParameter("quantity");
            int quantity = 1;
            if (quantityParam != null && !quantityParam.trim().isEmpty()) {
                try {
                    quantity = Integer.parseInt(quantityParam.trim());
                } catch (Exception e) {
                    quantity = 1;
                }
            }

            if (idParam != null && !idParam.trim().isEmpty()) {
                try {
                    int productId = Integer.parseInt(idParam.trim());
                    
                    // Thêm sản phẩm vào giỏ
                    cartService.addToCart(user, productId, quantity);

                    // Cập nhật lại giỏ hàng mới nhất trong Session
                    Cart updatedCart = cartService.getCartByUser(user);
                    session.setAttribute("cart", updatedCart);

                    session.setAttribute("message", "Đã thêm sản phẩm vào giỏ hàng thành công!");
                    session.removeAttribute("error"); // Xóa lỗi cũ nếu có
                } catch (Exception e) {
                    e.printStackTrace();
                    session.setAttribute("error", "Lỗi hệ thống khi thêm sản phẩm: " + e.getMessage());
                }
            } else {
                session.setAttribute("error", "Không tìm thấy ID sản phẩm!");
            }
            resp.sendRedirect(req.getContextPath() + "/cart");

        // 3. XÓA 1 SẢN PHẨM KHỎI GIỎ HÀNG
        } else if ("/cart/remove".equals(path)) {
            String idParam = req.getParameter("productId");
            if (idParam == null || idParam.trim().isEmpty()) {
                idParam = req.getParameter("id");
            }

            if (idParam != null && !idParam.trim().isEmpty()) {
                try {
                    int productId = Integer.parseInt(idParam.trim());
                    cartService.removeFromCart(user, productId);

                    Cart updatedCart = cartService.getCartByUser(user);
                    session.setAttribute("cart", updatedCart);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            resp.sendRedirect(req.getContextPath() + "/cart");

        // 4. CẬP NHẬT SỐ LƯỢNG SẢN PHẨM IN GIỎ HÀNG
        } else if ("/cart/update".equals(path)) {
            String idParam = req.getParameter("productId");
            if (idParam == null || idParam.trim().isEmpty()) {
                idParam = req.getParameter("id");
            }
            String quantityParam = req.getParameter("quantity");
            
            if (idParam != null && quantityParam != null) {
                try {
                    int productId = Integer.parseInt(idParam.trim());
                    int qty = Integer.parseInt(quantityParam.trim());
                    cartService.updateQuantity(user, productId, qty);

                    Cart updatedCart = cartService.getCartByUser(user);
                    session.setAttribute("cart", updatedCart);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            resp.sendRedirect(req.getContextPath() + "/cart");

        // 5. XÓA TOÀN BỘ GIỎ HÀNG
        } else if ("/cart/clear".equals(path)) {
            try {
                cartService.clearCart(user);
                session.removeAttribute("cart");
                session.setAttribute("message", "Đã xóa toàn bộ giỏ hàng!");
            } catch (Exception e) {
                e.printStackTrace();
            }
            resp.sendRedirect(req.getContextPath() + "/cart");

        // 6. TRANG THANH TOÁN
        } else if ("/cart/checkout".equals(path)) {
            Cart cart = cartService.getCartByUser(user);
            if (cart == null || cart.getItems() == null || cart.getItems().isEmpty()) {
                session.setAttribute("error", "Giỏ hàng trống! Vui lòng thêm sản phẩm trước khi thanh toán.");
                resp.sendRedirect(req.getContextPath() + "/cart");
            } else {
                req.getRequestDispatcher("/views/checkout.jsp").forward(req, resp);
            }

        // 7. HIỂN THỊ TRANG GIỎ HÀNG (`/cart`)
        } else {
            Cart cart = cartService.getCartByUser(user);
            req.setAttribute("cart", cart);
            session.setAttribute("cart", cart);

            // Chuyển Flash Message từ Session sang Request rồi xóa ngay trong Session
            if (session.getAttribute("message") != null) {
                req.setAttribute("message", session.getAttribute("message"));
                session.removeAttribute("message");
            }
            if (session.getAttribute("error") != null) {
                req.setAttribute("error", session.getAttribute("error"));
                session.removeAttribute("error");
            }

            req.getRequestDispatcher("/views/cart.jsp").forward(req, resp);
        }
    }
}