package vn.iotstar.controllers;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import vn.iotstar.entity.Cart;
import vn.iotstar.entity.User;
import vn.iotstar.services.ICartService;
import vn.iotstar.services.impl.CartServiceImpl;

@WebServlet(urlPatterns = {"/cart", "/cart/add", "/cart/update", "/cart/remove", "/cart/clear", "/cart/checkout"})
public class CartController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private ICartService cartService = new CartServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        User user = (User) session.getAttribute("account");
        
        // Yêu cầu đăng nhập trước khi thao tác với giỏ hàng
        if (user == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        String url = req.getRequestURI();

        // 1. THÊM SẢN PHẨM VÀO GIỎ HÀNG
        if (url.contains("/cart/add")) {
            String idParam = req.getParameter("productId");
            if (idParam != null && !idParam.trim().isEmpty()) {
                try {
                    int productId = Integer.parseInt(idParam);
                    cartService.addToCart(user, productId, 1);
                    session.setAttribute("message", "Đã thêm sản phẩm vào giỏ hàng!");
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    session.setAttribute("error", "Mã sản phẩm không hợp lệ!");
                }
            }
            // Sửa đường dẫn redirect từ /admin/products thành /cart (hoặc /product)
            resp.sendRedirect(req.getContextPath() + "/cart");

        // 2. XÓA 1 SẢN PHẨM KHỎI GIỎ HÀNG
        } else if (url.contains("/cart/remove")) {
            String idParam = req.getParameter("productId");
            if (idParam != null && !idParam.trim().isEmpty()) {
                try {
                    int productId = Integer.parseInt(idParam);
                    cartService.removeFromCart(user, productId);
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }
            }
            resp.sendRedirect(req.getContextPath() + "/cart");

        // 3. XÓA TOÀN BỘ GIỎ HÀNG
        } else if (url.contains("/cart/clear")) {
            cartService.clearCart(user);
            session.setAttribute("message", "Đã xóa toàn bộ giỏ hàng!");
            resp.sendRedirect(req.getContextPath() + "/cart");

        // 4. TRANG THANH TOÁN
        } else if (url.contains("/cart/checkout")) {
            Cart cart = cartService.getCartByUser(user);
            if (cart == null || cart.getItems() == null || cart.getItems().isEmpty()) {
                session.setAttribute("error", "Giỏ hàng trống! Vui lòng thêm sản phẩm trước khi thanh toán.");
                resp.sendRedirect(req.getContextPath() + "/cart");
            } else {
                req.getRequestDispatcher("/views/checkout.jsp").forward(req, resp);
            }

        // 5. HIỂN THỊ GIỎ HÀNG (/cart)
        } else {
            Cart cart = cartService.getCartByUser(user);
            req.setAttribute("cart", cart);
            req.getRequestDispatcher("/views/cart.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        User user = (User) session.getAttribute("account");
        
        if (user == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        String url = req.getRequestURI();
        
        // CẬP NHẬT SỐ LƯỢNG SẢN PHẨM IN GIỎ HÀNG
        if (url.contains("/cart/update")) {
            String idParam = req.getParameter("productId");
            String quantityParam = req.getParameter("quantity");
            
            if (idParam != null && quantityParam != null) {
                try {
                    int productId = Integer.parseInt(idParam);
                    int quantity = Integer.parseInt(quantityParam);
                    cartService.updateQuantity(user, productId, quantity);
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }
            }
            resp.sendRedirect(req.getContextPath() + "/cart");
        }
    }
}