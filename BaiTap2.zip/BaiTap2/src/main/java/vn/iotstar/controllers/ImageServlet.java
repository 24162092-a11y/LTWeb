package vn.iotstar.controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Path;
import java.nio.file.Paths;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import vn.iotstar.utils.Constant;

@WebServlet("/image")
public class ImageServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String fname = req.getParameter("fname");
        if (fname == null || fname.trim().isEmpty()) {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Thiếu tên file");
            return;
        }

        // 1. Bảo mật Chống tấn công Directory Traversal (ngăn chặn truy cập file ngoài thư mục qua path kiểu ../../)
        String uploadPathStr = Constant.UPLOAD_DIR;
        Path baseDir = Paths.get(uploadPathStr).toAbsolutePath().normalize();
        Path filePath = baseDir.resolve(fname).normalize();

        if (!filePath.startsWith(baseDir)) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN, "Không có quyền truy cập file này");
            return;
        }

        File file = filePath.toFile();

        // 2. Kiểm tra file tồn tại và không phải là thư mục
        if (!file.exists() || file.isDirectory()) {
            resp.sendError(HttpServletResponse.SC_NOT_FOUND, "File không tồn tại");
            return;
        }

        // 3. Cấu hình Cache Control (giúp trình duyệt lưu cache ảnh 7 ngày, load trang nhanh hơn)
        long cacheAgeInSeconds = 7 * 24 * 60 * 60; // 7 ngày
        resp.setHeader("Cache-Control", "public, max-age=" + cacheAgeInSeconds);
        resp.setDateHeader("Expires", System.currentTimeMillis() + (cacheAgeInSeconds * 1000));
        resp.setDateHeader("Last-Modified", file.lastModified());

        // 4. Nhận diện MIME Type
        String mimeType = getServletContext().getMimeType(file.getName());
        if (mimeType == null) {
            mimeType = "application/octet-stream";
        }
        resp.setContentType(mimeType);
        
        // Dùng file.length() kiểu long
        if (file.length() <= Integer.MAX_VALUE) {
            resp.setContentLength((int) file.length());
        } else {
            resp.setHeader("Content-Length", String.valueOf(file.length()));
        }

        // 5. Stream dữ liệu nhanh bằng API Java 9+ (transferTo)
        try (FileInputStream in = new FileInputStream(file);
             OutputStream out = resp.getOutputStream()) {
            in.transferTo(out);
        } catch (IOException e) {
            // Lỗi xảy ra khi người dùng hủy tải ảnh giữa chừng
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }
}