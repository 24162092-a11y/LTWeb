package vn.iotstar.controllers;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import vn.iotstar.utils.Constant;

@WebServlet(
    name = "MultiPartServlet",
    urlPatterns = {"/multiPartServlet"}
)
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024 * 1,  // 1MB
    maxFileSize = 1024 * 1024 * 5,       // 5MB
    maxRequestSize = 1024 * 1024 * 10    // 10MB
)
public class MultipartServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Trích xuất tên file từ Header "content-disposition"
    private String getFileName(Part part) {
        for (String content : part.getHeader("content-disposition").split(";")) {
            if (content.trim().startsWith("filename")) {
                String fileName = content.substring(content.indexOf("=") + 2, content.length() - 1);
                // Xử lý trường hợp trình duyệt trả về đường dẫn đầy đủ thay vì chỉ mỗi tên file
                return new File(fileName).getName();
            }
        }
        return null;
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");

        // Lấy thư mục upload từ class Constant
        String uploadPath = Constant.UPLOAD_DIR;

        // Tạo thư mục nếu chưa tồn tại
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) {
            uploadDir.mkdirs();
        }

        try {
            String uploadedFileName = "";
            for (Part part : request.getParts()) {
                String fileName = getFileName(part);
                
                // Chỉ lưu nếu part có chứa file thực sự
                if (fileName != null && !fileName.isEmpty()) {
                    part.write(uploadPath + File.separator + fileName);
                    uploadedFileName = fileName;
                }
            }
            
            if (!uploadedFileName.isEmpty()) {
                request.setAttribute("message", "File " + uploadedFileName + " uploaded successfully to " + uploadPath);
            } else {
                request.setAttribute("message", "Please select a file to upload!");
            }
            
        } catch (FileNotFoundException fne) {
            request.setAttribute("message", "Error uploading file: " + fne.getMessage());
        } catch (Exception e) {
            request.setAttribute("message", "System error: " + e.getMessage());
        }

        // Forward sang trang hiển thị kết quả
        getServletContext().getRequestDispatcher("/views/result.jsp").forward(request, response);
    }
}