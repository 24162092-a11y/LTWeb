package vn.iotstar.controllers;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import vn.iotstar.entity.Order;
import vn.iotstar.entity.User;
import vn.iotstar.services.IOrderService;
import vn.iotstar.services.impl.OrderServiceImpl;

@WebServlet(urlPatterns = {"/order/create", "/order/history", "/order/detail", "/order/success", "/order/clear-session"})
public class OrderController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private IOrderService orderService = new OrderServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String url = req.getRequestURI();
        HttpSession session = req.getSession();
        User user = (User) session.getAttribute("account");

        if (user == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        if (url.contains("/order/success")) {
            // Hiển thị trang thành công
            req.getRequestDispatcher("/views/order-success.jsp").forward(req, resp);

        } else if (url.contains("/order/clear-session")) {
            // Xóa session attribute orderId nếu cần
            session.removeAttribute("orderId");
            session.removeAttribute("message");
            resp.setStatus(HttpServletResponse.SC_OK);

        } else if (url.contains("/order/history")) {
            List<Order> orders = orderService.getOrdersByUser(user);
            req.setAttribute("orders", orders);
            req.getRequestDispatcher("/views/order-history.jsp").forward(req, resp);

        } else if (url.contains("/order/detail")) {
            int orderId = Integer.parseInt(req.getParameter("id"));
            Order order = orderService.findById(orderId);
            req.setAttribute("order", order);
            req.getRequestDispatcher("/views/order-detail.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String url = req.getRequestURI();
        HttpSession session = req.getSession();
        User user = (User) session.getAttribute("account");

        if (user == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        if (url.contains("/order/create")) {
            String shippingAddress = req.getParameter("shippingAddress");
            String note = req.getParameter("note");

            Order order = orderService.createOrder(user, shippingAddress, note);
            if (order != null) {
                // Lưu orderId vào session để hiển thị trên trang thành công
                session.setAttribute("orderId", order.getOrderId());
                session.setAttribute("message", "Đặt hàng thành công! Mã đơn hàng: #" + order.getOrderId());
                resp.sendRedirect(req.getContextPath() + "/order/success");
            } else {
                session.setAttribute("error", "Giỏ hàng trống hoặc tạo đơn hàng thất bại!");
                resp.sendRedirect(req.getContextPath() + "/cart");
            }
        }
    }
}