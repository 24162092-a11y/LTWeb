package vn.iotstar.controllers;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import vn.iotstar.entity.Category;
import vn.iotstar.entity.Product;
import vn.iotstar.services.ICategoryService;
import vn.iotstar.services.IProductService;
import vn.iotstar.services.impl.CategoryServiceImpl;
import vn.iotstar.services.impl.ProductServiceImpl;
import vn.iotstar.utils.Constant;

@MultipartConfig(
    fileSizeThreshold = 1024 * 1024 * 2,
    maxFileSize = 1024 * 1024 * 10,
    maxRequestSize = 1024 * 1024 * 50
)
@WebServlet(urlPatterns = {
    "/product",
    "/products",
    "/product/detail",
    "/admin/products",
    "/admin/product/add",
    "/admin/product/insert",
    "/admin/product/edit",
    "/admin/product/update",
    "/admin/product/delete"
})
public class ProductController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private IProductService productService = new ProductServiceImpl();
    private ICategoryService categoryService = new CategoryServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String url = req.getRequestURI();

        // 1. XỬ LÝ XEM CHI TIẾT SẢN PHẨM (/product/detail?id=X hoặc ?productId=X)
        if (url.contains("/product/detail")) {
            String idParam = req.getParameter("id");
            if (idParam == null || idParam.trim().isEmpty()) {
                idParam = req.getParameter("productId");
            }
            if (idParam != null && !idParam.trim().isEmpty()) {
                try {
                    int id = Integer.parseInt(idParam);
                    Product product = productService.findById(id);
                    req.setAttribute("product", product);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            req.getRequestDispatcher("/views/product-detail.jsp").forward(req, resp);

        // 2. XỬ LÝ DANH SÁCH SẢN PHẨM PHÂN TRANG CHO USER (/product)
        } else if (url.endsWith("/product") || url.endsWith("/products")) {
            int pageSize = 6;
            String pageParam = req.getParameter("page");
            int currentPage = 1;
            if (pageParam != null && !pageParam.isEmpty()) {
                try {
                    currentPage = Integer.parseInt(pageParam);
                } catch (Exception e) {
                    currentPage = 1;
                }
            }

            int totalProducts = productService.count();
            int totalPages = (int) Math.ceil((double) totalProducts / pageSize);
            List<Product> list = productService.findAllPage(currentPage, pageSize);

            req.setAttribute("productList", list);
            req.setAttribute("totalPages", totalPages);
            req.setAttribute("currentPage", currentPage);
            req.getRequestDispatcher("/views/product-list.jsp").forward(req, resp);

        // 3. XỬ LÝ DÀNH CHO ADMIN (/admin/*)
        } else if (url.contains("/admin/products")) {
            List<Product> list = productService.findAll();
            req.setAttribute("productList", list);
            req.getRequestDispatcher("/views/admin/product-list.jsp").forward(req, resp);

        } else if (url.contains("/admin/product/add")) {
            List<Category> categories = categoryService.findAll();
            req.setAttribute("categories", categories);
            req.getRequestDispatcher("/views/admin/product-add.jsp").forward(req, resp);

        // ĐÃ SỬA LỖI: Bắt an toàn idParam tại trang edit
        } else if (url.contains("/admin/product/edit")) {
            String idParam = req.getParameter("id");
            if (idParam == null || idParam.trim().isEmpty()) {
                idParam = req.getParameter("productId");
            }

            if (idParam != null && !idParam.trim().isEmpty()) {
                try {
                    int id = Integer.parseInt(idParam);
                    Product product = productService.findById(id);
                    List<Category> categories = categoryService.findAll();
                    req.setAttribute("product", product);
                    req.setAttribute("categories", categories);
                    req.getRequestDispatcher("/views/admin/product-edit.jsp").forward(req, resp);
                    return;
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            // Nếu id bị trống hoặc lỗi thì chuyển hướng về danh sách admin
            resp.sendRedirect(req.getContextPath() + "/admin/products");

        // ĐÃ SỬA LỖI: Bắt an toàn idParam tại chức năng xóa
        } else if (url.contains("/admin/product/delete")) {
            String idParam = req.getParameter("id");
            if (idParam == null || idParam.trim().isEmpty()) {
                idParam = req.getParameter("productId");
            }

            if (idParam != null && !idParam.trim().isEmpty()) {
                try {
                    int id = Integer.parseInt(idParam);
                    productService.delete(id);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            resp.sendRedirect(req.getContextPath() + "/admin/products");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String url = req.getRequestURI();

        if (url.contains("/admin/product/insert")) {
            String productName = req.getParameter("productName");
            double price = Double.parseDouble(req.getParameter("price"));
            String description = req.getParameter("description");
            int categoryId = Integer.parseInt(req.getParameter("categoryId"));

            Product product = new Product();
            product.setProductName(productName);
            product.setPrice(price);
            product.setDescription(description);

            Category category = categoryService.findById(categoryId);
            product.setCategory(category);

            // Upload ảnh
            String uploadPath = Constant.UPLOAD_DIR;
            File uploadDir = new File(uploadPath);
            if (!uploadDir.exists()) uploadDir.mkdirs();

            try {
                Part part = req.getPart("images");
                if (part != null && part.getSize() > 0) {
                    String filename = Paths.get(part.getSubmittedFileName()).getFileName().toString();
                    int index = filename.lastIndexOf(".");
                    String ext = filename.substring(index + 1);
                    String fname = System.currentTimeMillis() + "." + ext;
                    part.write(uploadPath + "/" + fname);
                    product.setImages(fname);
                } else {
                    product.setImages("avatar.png");
                }
            } catch (Exception e) {
                e.printStackTrace();
                product.setImages("avatar.png");
            }

            try {
                productService.insert(product);
            } catch (Exception e) {
                e.printStackTrace();
            }
            resp.sendRedirect(req.getContextPath() + "/admin/products");

        } else if (url.contains("/admin/product/update")) {
            String idParam = req.getParameter("productId");
            if (idParam == null || idParam.trim().isEmpty()) {
                idParam = req.getParameter("id");
            }

            if (idParam != null && !idParam.trim().isEmpty()) {
                try {
                    int productId = Integer.parseInt(idParam);
                    String productName = req.getParameter("productName");
                    double price = Double.parseDouble(req.getParameter("price"));
                    String description = req.getParameter("description");
                    int categoryId = Integer.parseInt(req.getParameter("categoryId"));

                    Product product = productService.findById(productId);
                    if (product != null) {
                        product.setProductName(productName);
                        product.setPrice(price);
                        product.setDescription(description);
                        Category category = categoryService.findById(categoryId);
                        product.setCategory(category);

                        // Xử lý upload ảnh mới
                        String uploadPath = Constant.UPLOAD_DIR;
                        File uploadDir = new File(uploadPath);
                        if (!uploadDir.exists()) uploadDir.mkdirs();

                        try {
                            Part part = req.getPart("images");
                            if (part != null && part.getSize() > 0) {
                                String oldFile = product.getImages();
                                if (oldFile != null && !oldFile.startsWith("http") && !oldFile.equals("avatar.png")) {
                                    File old = new File(uploadPath + "/" + oldFile);
                                    if (old.exists()) old.delete();
                                }
                                String filename = Paths.get(part.getSubmittedFileName()).getFileName().toString();
                                int index = filename.lastIndexOf(".");
                                String ext = filename.substring(index + 1);
                                String fname = System.currentTimeMillis() + "." + ext;
                                part.write(uploadPath + "/" + fname);
                                product.setImages(fname);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        productService.update(product);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            resp.sendRedirect(req.getContextPath() + "/admin/products");
        }
    }
}