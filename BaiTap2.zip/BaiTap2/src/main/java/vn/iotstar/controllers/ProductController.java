package vn.iotstar.controllers;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import vn.iotstar.entity.Category;
import vn.iotstar.entity.Product;
import vn.iotstar.services.ICategoryService;
import vn.iotstar.services.IProductService;
import vn.iotstar.services.impl.CategoryServiceImpl;
import vn.iotstar.services.impl.ProductServiceImpl;
import vn.iotstar.utils.Constant;

@MultipartConfig(
    fileSizeThreshold = 1024 * 1024 * 2,
    maxFileSize = 1024 * 1024 * 10,
    maxRequestSize = 1024 * 1024 * 50
)
@WebServlet(urlPatterns = {
    "/product",
    "/products",
    "/product/detail",
    "/admin/products",
    "/admin/product/add",
    "/admin/product/insert",
    "/admin/product/edit",
    "/admin/product/update",
    "/admin/product/delete"
})
public class ProductController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private IProductService productService = new ProductServiceImpl();
    private ICategoryService categoryService = new CategoryServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String path = req.getServletPath();

        // 1. TRANG DANH SÁCH SẢN PHẨM ADMIN (6 SẢN PHẨM / TRANG)
        if (path.equals("/admin/products")) {
            int page = 1;
            int pageSize = 6;
            String pageParam = req.getParameter("page");
            if (pageParam != null && !pageParam.trim().isEmpty()) {
                try {
                    page = Integer.parseInt(pageParam);
                } catch (Exception e) {
                    page = 1;
                }
            }

            int totalProducts = productService.count();
            int totalPages = (int) Math.ceil((double) totalProducts / pageSize);
            if (totalPages == 0) totalPages = 1;

            List<Product> list = productService.findAllPage(page, pageSize);

            req.setAttribute("productList", list);
            req.setAttribute("currentPage", page);
            req.setAttribute("totalPages", totalPages);
            req.getRequestDispatcher("/views/admin/product-list.jsp").forward(req, resp);

        // 2. TRANG THÊM SẢN PHẨM ADMIN
        } else if (path.equals("/admin/product/add")) {
            List<Category> categories = categoryService.findAll();
            req.setAttribute("categories", categories);
            req.getRequestDispatcher("/views/admin/product-add.jsp").forward(req, resp);

        // 3. TRANG SỬA SẢN PHẨM ADMIN
        } else if (path.equals("/admin/product/edit")) {
            String idParam = req.getParameter("id");
            if (idParam == null || idParam.trim().isEmpty()) {
                idParam = req.getParameter("productId");
            }

            if (idParam != null && !idParam.trim().isEmpty()) {
                try {
                    int id = Integer.parseInt(idParam);
                    Product product = productService.findById(id);
                    List<Category> categories = categoryService.findAll();
                    
                    if (product != null) {
                        req.setAttribute("product", product);
                        req.setAttribute("categories", categories);
                        req.getRequestDispatcher("/views/admin/product-edit.jsp").forward(req, resp);
                        return;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            resp.sendRedirect(req.getContextPath() + "/admin/products");

        // 4. XÓA SẢN PHẨM ADMIN
        } else if (path.equals("/admin/product/delete")) {
            String idParam = req.getParameter("id");
            if (idParam == null || idParam.trim().isEmpty()) {
                idParam = req.getParameter("productId");
            }

            if (idParam != null && !idParam.trim().isEmpty()) {
                try {
                    int id = Integer.parseInt(idParam);
                    productService.delete(id);
                    req.getSession().setAttribute("message", "Xóa sản phẩm thành công!");
                } catch (Exception e) {
                    e.printStackTrace();
                    req.getSession().setAttribute("error", "Lỗi khi xóa sản phẩm!");
                }
            }
            resp.sendRedirect(req.getContextPath() + "/admin/products");

        // 5. XEM CHI TIẾT SẢN PHẨM (USER/COMMON)
        } else if (path.equals("/product/detail")) {
            String idParam = req.getParameter("id");
            if (idParam == null || idParam.trim().isEmpty()) {
                idParam = req.getParameter("productId");
            }
            if (idParam != null && !idParam.trim().isEmpty()) {
                try {
                    int id = Integer.parseInt(idParam);
                    Product product = productService.findById(id);
                    req.setAttribute("product", product);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            req.getRequestDispatcher("/views/product-detail.jsp").forward(req, resp);

        // 6. TRANG CHỦ / USER LIST
        } else {
            int page = 1;
            int pageSize = 6;
            String pageParam = req.getParameter("page");
            if (pageParam != null && !pageParam.trim().isEmpty()) {
                try {
                    page = Integer.parseInt(pageParam);
                } catch (Exception e) {
                    page = 1;
                }
            }

            int totalProducts = productService.count();
            int totalPages = (int) Math.ceil((double) totalProducts / pageSize);
            if (totalPages == 0) totalPages = 1;

            List<Product> list = productService.findAllPage(page, pageSize);

            req.setAttribute("productList", list);
            req.setAttribute("currentPage", page);
            req.setAttribute("totalPages", totalPages);
            
            // Đã sửa đường dẫn trỏ thẳng ra /views/product-list.jsp
            req.getRequestDispatcher("/views/product-list.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        String path = req.getServletPath();

        // 1. THÊM SẢN PHẨM MỚI
        if (path.equals("/admin/product/insert")) {
            String productName = req.getParameter("productName");
            String priceStr = req.getParameter("price");
            String description = req.getParameter("description");
            String categoryIdStr = req.getParameter("categoryId");

            // --- BẮT ĐẦU VALIDATION SERVER-SIDE ---
            StringBuilder errors = new StringBuilder();

            if (productName == null || productName.trim().isEmpty()) {
                errors.append("Tên sản phẩm không được để trống.<br>");
            } else if (productName.trim().length() < 3) {
                errors.append("Tên sản phẩm phải có ít nhất 3 ký tự.<br>");
            }

            double price = 0;
            try {
                price = Double.parseDouble(priceStr);
                if (price < 1000) {
                    errors.append("Giá sản phẩm phải lớn hơn hoặc bằng 1,000 VNĐ.<br>");
                }
            } catch (Exception e) {
                errors.append("Giá sản phẩm không đúng định dạng số.<br>");
            }

            int categoryId = 0;
            try {
                categoryId = Integer.parseInt(categoryIdStr);
            } catch (Exception e) {
                errors.append("Vui lòng chọn danh mục sản phẩm hợp lệ.<br>");
            }

            // Nếu phát hiện lỗi Validation -> Trả lại giao diện form cùng thông báo lỗi
            if (errors.length() > 0) {
                req.setAttribute("error", errors.toString());
                req.setAttribute("categories", categoryService.findAll());
                req.getRequestDispatcher("/views/admin/product-add.jsp").forward(req, resp);
                return;
            }

            // --- NẾU DỮ LIỆU HỢP LỆ: XỬ LÝ LƯU DATABASE & UPLOAD ẢNH ---
            try {
                Product product = new Product();
                product.setProductName(productName);
                product.setPrice(price);
                product.setDescription(description);

                Category category = categoryService.findById(categoryId);
                product.setCategory(category);

                String uploadPath = Constant.UPLOAD_DIR;
                File uploadDir = new File(uploadPath);
                if (!uploadDir.exists()) uploadDir.mkdirs();

                Part part = req.getPart("images");
                if (part != null && part.getSize() > 0) {
                    String filename = Paths.get(part.getSubmittedFileName()).getFileName().toString();
                    if (!filename.isEmpty()) {
                        int index = filename.lastIndexOf(".");
                        String ext = index > 0 ? filename.substring(index + 1) : "png";
                        String fname = System.currentTimeMillis() + "." + ext;
                        part.write(uploadPath + File.separator + fname);
                        product.setImages(fname);
                    } else {
                        product.setImages("avatar.png");
                    }
                } else {
                    product.setImages("avatar.png");
                }

                productService.insert(product);
                req.getSession().setAttribute("message", "Thêm sản phẩm thành công!");
            } catch (Exception e) {
                e.printStackTrace();
                req.getSession().setAttribute("error", "Lỗi thêm sản phẩm: " + e.getMessage());
            }
            resp.sendRedirect(req.getContextPath() + "/admin/products");

        // 2. CẬP NHẬT SẢN PHẨM
        } else if (path.equals("/admin/product/update")) {
            String idParam = req.getParameter("productId");
            if (idParam == null || idParam.trim().isEmpty()) {
                idParam = req.getParameter("id");
            }

            String productName = req.getParameter("productName");
            String priceStr = req.getParameter("price");
            String description = req.getParameter("description");
            String categoryIdStr = req.getParameter("categoryId");

            // --- BẮT ĐẦU VALIDATION SERVER-SIDE CHO EDIT ---
            StringBuilder errors = new StringBuilder();

            if (productName == null || productName.trim().isEmpty()) {
                errors.append("Tên sản phẩm không được để trống.<br>");
            }

            double price = 0;
            try {
                price = Double.parseDouble(priceStr);
                if (price < 1000) {
                    errors.append("Giá sản phẩm phải lớn hơn hoặc bằng 1,000 VNĐ.<br>");
                }
            } catch (Exception e) {
                errors.append("Giá sản phẩm không đúng định dạng số.<br>");
            }

            int categoryId = 0;
            try {
                categoryId = Integer.parseInt(categoryIdStr);
            } catch (Exception e) {
                errors.append("Vui lòng chọn danh mục hợp lệ.<br>");
            }

            int productId = 0;
            try {
                productId = Integer.parseInt(idParam);
            } catch (Exception e) {
                errors.append("Mã sản phẩm không hợp lệ.<br>");
            }

            // Nếu phát hiện lỗi -> Forward về lại trang product-edit.jsp
            if (errors.length() > 0) {
                req.setAttribute("error", errors.toString());
                if (productId > 0) {
                    req.setAttribute("product", productService.findById(productId));
                }
                req.setAttribute("categories", categoryService.findAll());
                req.getRequestDispatcher("/views/admin/product-edit.jsp").forward(req, resp);
                return;
            }

            // --- NẾU HỢP LỆ -> THỰC HIỆN CẬP NHẬT ---
            try {
                Product product = productService.findById(productId);
                if (product != null) {
                    product.setProductName(productName);
                    product.setPrice(price);
                    product.setDescription(description);
                    
                    Category category = categoryService.findById(categoryId);
                    product.setCategory(category);

                    String uploadPath = Constant.UPLOAD_DIR;
                    File uploadDir = new File(uploadPath);
                    if (!uploadDir.exists()) uploadDir.mkdirs();

                    Part part = req.getPart("images");
                    if (part != null && part.getSize() > 0) {
                        String oldFile = product.getImages();
                        if (oldFile != null && !oldFile.startsWith("http") && !oldFile.equals("avatar.png")) {
                            File old = new File(uploadPath + File.separator + oldFile);
                            if (old.exists()) old.delete();
                        }
                        String filename = Paths.get(part.getSubmittedFileName()).getFileName().toString();
                        if (!filename.isEmpty()) {
                            int index = filename.lastIndexOf(".");
                            String ext = index > 0 ? filename.substring(index + 1) : "png";
                            String fname = System.currentTimeMillis() + "." + ext;
                            part.write(uploadPath + File.separator + fname);
                            product.setImages(fname);
                        }
                    }

                    productService.update(product);
                    req.getSession().setAttribute("message", "Cập nhật sản phẩm thành công!");
                }
            } catch (Exception e) {
                e.printStackTrace();
                req.getSession().setAttribute("error", "Lỗi cập nhật sản phẩm: " + e.getMessage());
            }
            resp.sendRedirect(req.getContextPath() + "/admin/products");
        }
    }
}