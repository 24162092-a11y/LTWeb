package vn.iotstar.controllers;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;

import vn.iotstar.entity.User;
import vn.iotstar.services.IUserService;
import vn.iotstar.services.impl.UserServiceImpl;
import vn.iotstar.utils.Constant;
import vn.iotstar.utils.UploadUtils;

@MultipartConfig(
    fileSizeThreshold = 1024 * 1024 * 2, // 2MB
    maxFileSize = 1024 * 1024 * 10,      // 10MB
    maxRequestSize = 1024 * 1024 * 50    // 50MB
)
@WebServlet(urlPatterns = {"/user/profile", "/profile"})
public class ProfileController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private IUserService userService = new UserServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        User account = (User) session.getAttribute("account");

        if (account == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        User user = userService.findById(account.getId());
        req.setAttribute("user", user);
        req.getRequestDispatcher("/views/profile.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        HttpSession session = req.getSession();
        User account = (User) session.getAttribute("account");

        if (account == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        User user = userService.findById(account.getId());

        String fullname = req.getParameter("fullname");
        String phone = req.getParameter("phone");

        if (fullname == null || fullname.trim().isEmpty()) {
            req.setAttribute("error", "Họ và tên không được để trống!");
            req.setAttribute("user", user);
            req.getRequestDispatcher("/views/profile.jsp").forward(req, resp);
            return;
        }

        user.setFullname(fullname.trim());
        user.setPhone(phone != null ? phone.trim() : "");

        // Xử lý Upload file ảnh đại diện
        Part filePart = req.getPart("imageFile");
        if (filePart != null && filePart.getSize() > 0) {
            String fileName = UploadUtils.processUpload(filePart, Constant.UPLOAD_DIR);
            if (fileName != null) {
                user.setImages(fileName);
            }
        }

        // Cập nhật thông tin vào DB
        userService.update(user);

        // Cập nhật lại Session để Header cập nhật Avatar lập tức
        session.setAttribute("account", user);

        // ĐÃ SỬA: Kiểm tra Role của User để chuyển hướng chính xác
        if (user.getRoleid() == 1) {
            // Nếu là Admin -> Chuyển về trang danh sách sản phẩm của Admin
            resp.sendRedirect(req.getContextPath() + "/admin/products");
        } else {
            // Nếu là User thường -> Giữ người dùng ở lại trang hồ sơ cá nhân (hoặc "/products")
            resp.sendRedirect(req.getContextPath() + "/profile");
        }
    }
}