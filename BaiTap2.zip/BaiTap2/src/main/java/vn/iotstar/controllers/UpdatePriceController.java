package vn.iotstar.controllers;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import vn.iotstar.entity.Product;
import vn.iotstar.services.IProductService;
import vn.iotstar.services.impl.ProductServiceImpl;

@WebServlet("/admin/product/update-price")
public class UpdatePriceController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private IProductService productService = new ProductServiceImpl();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        try {
            int productId = Integer.parseInt(req.getParameter("productId"));
            double price = Double.parseDouble(req.getParameter("price"));

            Product product = productService.findById(productId);
            if (product != null) {
                product.setPrice(price);
                productService.update(product);
                session.setAttribute("message", "Cập nhật giá thành công!");
            } else {
                session.setAttribute("error", "Không tìm thấy sản phẩm!");
            }
        } catch (NumberFormatException e) {
            session.setAttribute("error", "Dữ liệu nhập không hợp lệ!");
            e.printStackTrace();
        } catch (Exception e) {
            session.setAttribute("error", "Cập nhật giá thất bại: " + e.getMessage());
            e.printStackTrace();
        }
        resp.sendRedirect(req.getContextPath() + "/admin/products");
    }
}