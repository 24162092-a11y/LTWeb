package vn.iotstar.dao;

import java.util.List;

import vn.iotstar.entity.Cart;
import vn.iotstar.entity.CartItem;

public interface ICartDao {
    Cart findByUserId(int userId);
    void insert(Cart cart);
    void update(Cart cart);
    CartItem findCartItem(int cartId, int productId);
    void insertCartItem(CartItem item);
    void updateCartItem(CartItem item);
    void deleteCartItem(int cartId, int productId);
    List<CartItem> clearCartItems(int cartId);
	List<CartItem> findCartItemsByCartId(int cartId);
}