package vn.iotstar.dao;

import vn.iotstar.entity.Order;
import vn.iotstar.entity.OrderItem;
import java.util.List;

public interface IOrderDao {
    void insert(Order order, List<OrderItem> items);
    Order findById(int orderId);
    List<Order> findByUserId(int userId);
    void updateStatus(int orderId, String status);
}