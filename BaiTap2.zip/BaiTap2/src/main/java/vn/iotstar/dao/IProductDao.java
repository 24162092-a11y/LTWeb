package vn.iotstar.dao;

import java.util.List;
import vn.iotstar.entity.Product;

public interface IProductDao {
    void insert(Product product);
    void update(Product product);
    void delete(int id) throws Exception;
    Product findById(int id);
    List<Product> findAll();
    List<Product> searchByName(String keyword);
    List<Product> findAll(int page, int pageSize);
    List<Product> findTop10();
    int count();
	List<Product> findAllPage(int page, int pageSize);
}	