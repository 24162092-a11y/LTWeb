package vn.iotstar.dao.impl;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.TypedQuery;
import vn.iotstar.configs.JpaConfig;
import vn.iotstar.dao.ICartDao;
import vn.iotstar.entity.Cart;
import vn.iotstar.entity.CartItem;

public class CartDao implements ICartDao {

    @Override
    public Cart findByUserId(int userId) {
        EntityManager em = JpaConfig.getEntityManager();
        try {
            // JPQL an toàn: LEFT JOIN FETCH để lấy luôn danh sách CartItems và Product
            String jpql = "SELECT DISTINCT c FROM Cart c " +
                         "LEFT JOIN FETCH c.items i " +
                         "LEFT JOIN FETCH i.product " +
                         "WHERE c.user.id = :userId";
            
            TypedQuery<Cart> query = em.createQuery(jpql, Cart.class);
            query.setParameter("userId", userId);
            
            List<Cart> list = query.getResultList();
            if (list != null && !list.isEmpty()) {
                return list.get(0);
            }
            
            // Fallback nếu User dùng getter c.user.userId
            String jpql2 = "SELECT DISTINCT c FROM Cart c " +
                          "LEFT JOIN FETCH c.items i " +
                          "LEFT JOIN FETCH i.product " +
                          "WHERE c.user.userId = :userId";
            TypedQuery<Cart> query2 = em.createQuery(jpql2, Cart.class);
            query2.setParameter("userId", userId);
            
            List<Cart> list2 = query2.getResultList();
            return (list2 != null && !list2.isEmpty()) ? list2.get(0) : null;

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            em.close();
        }
    }

    @Override
    public void insert(Cart cart) {
        EntityManager em = JpaConfig.getEntityManager();
        EntityTransaction trans = em.getTransaction();
        try {
            trans.begin();
            em.persist(cart);
            trans.commit();
        } catch (Exception e) {
            if (trans.isActive()) trans.rollback();
            e.printStackTrace();
        } finally {
            em.close();
        }
    }

    @Override
    public void update(Cart cart) {
        EntityManager em = JpaConfig.getEntityManager();
        EntityTransaction trans = em.getTransaction();
        try {
            trans.begin();
            em.merge(cart);
            trans.commit();
        } catch (Exception e) {
            if (trans.isActive()) trans.rollback();
            e.printStackTrace();
        } finally {
            em.close();
        }
    }

    @Override
    public CartItem findCartItem(int cartId, int productId) {
        EntityManager em = JpaConfig.getEntityManager();
        try {
            // Truy vấn linh hoạt theo cả cart.id hoặc cart.cartId
            String jpql = "SELECT ci FROM CartItem ci " +
                         "WHERE (ci.cart.id = :cartId OR ci.cart.cartId = :cartId) " +
                         "AND (ci.product.id = :productId OR ci.product.productId = :productId)";
            
            TypedQuery<CartItem> query = em.createQuery(jpql, CartItem.class);
            query.setParameter("cartId", cartId);
            query.setParameter("productId", productId);
            
            List<CartItem> list = query.getResultList();
            return (list != null && !list.isEmpty()) ? list.get(0) : null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            em.close();
        }
    }

    @Override
    public void insertCartItem(CartItem item) {
        EntityManager em = JpaConfig.getEntityManager();
        EntityTransaction trans = em.getTransaction();
        try {
            trans.begin();
            
            // Re-attach Cart và Product vào Persistence Context hiện tại trước khi lưu
            Cart cart = em.find(Cart.class, item.getCart().getCartId() != 0 ? item.getCart().getCartId() : item.getCart().getCartId());
            if (cart != null) {
                item.setCart(cart);
            }
            
            em.persist(item);
            trans.commit();
        } catch (Exception e) {
            if (trans.isActive()) trans.rollback();
            e.printStackTrace();
        } finally {
            em.close();
        }
    }

    @Override
    public void updateCartItem(CartItem item) {
        EntityManager em = JpaConfig.getEntityManager();
        EntityTransaction trans = em.getTransaction();
        try {
            trans.begin();
            em.merge(item);
            trans.commit();
        } catch (Exception e) {
            if (trans.isActive()) trans.rollback();
            e.printStackTrace();
        } finally {
            em.close();
        }
    }

    @Override
    public void deleteCartItem(int cartId, int productId) {
        EntityManager em = JpaConfig.getEntityManager();
        EntityTransaction trans = em.getTransaction();
        try {
            trans.begin();
            String jpql = "DELETE FROM CartItem ci " +
                         "WHERE (ci.cart.id = :cartId OR ci.cart.cartId = :cartId) " +
                         "AND (ci.product.id = :productId OR ci.product.productId = :productId)";
            em.createQuery(jpql)
              .setParameter("cartId", cartId)
              .setParameter("productId", productId)
              .executeUpdate();
            trans.commit();
        } catch (Exception e) {
            if (trans.isActive()) trans.rollback();
            e.printStackTrace();
        } finally {
            em.close();
        }
    }

    @Override
    public List clearCartItems(int cartId) {
        EntityManager em = JpaConfig.getEntityManager();
        EntityTransaction trans = em.getTransaction();
        try {
            trans.begin();
            String jpql = "DELETE FROM CartItem ci WHERE ci.cart.id = :cartId OR ci.cart.cartId = :cartId";
            em.createQuery(jpql).setParameter("cartId", cartId).executeUpdate();
            trans.commit();
        } catch (Exception e) {
            if (trans.isActive()) trans.rollback();
            e.printStackTrace();
        } finally {
            em.close();
        }
		return null;
    }

	@Override
	public List<CartItem> findCartItemsByCartId(int cartId) {
		// TODO Auto-generated method stub
		return null;
	}
}