package vn.iotstar.dao.impl;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.TypedQuery;
import vn.iotstar.configs.JpaConfig;
import vn.iotstar.dao.IOrderDao;
import vn.iotstar.entity.Order;
import vn.iotstar.entity.OrderItem;
import java.util.List;

public class OrderDao implements IOrderDao {
    private EntityManager getEntityManager() {
        return JpaConfig.getEntityManager();
    }

    @Override
    public void insert(Order order, List<OrderItem> items) {
        EntityManager em = getEntityManager();
        EntityTransaction trans = em.getTransaction();
        try {
            trans.begin();
            em.persist(order);
            // Lưu các order items
            for (OrderItem item : items) {
                item.setOrder(order);
                em.persist(item);
            }
            trans.commit();
        } catch (Exception e) {
            if (trans.isActive()) trans.rollback();
            e.printStackTrace();
        } finally {
            em.close();
        }
    }

    @Override
    public Order findById(int orderId) {
        try {
            return getEntityManager().find(Order.class, orderId);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<Order> findByUserId(int userId) {
        try {
            String jpql = "SELECT o FROM Order o WHERE o.user.id = :userId ORDER BY o.orderDate DESC";
            TypedQuery<Order> query = getEntityManager().createQuery(jpql, Order.class);
            query.setParameter("userId", userId);
            return query.getResultList();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public void updateStatus(int orderId, String status) {
        EntityManager em = getEntityManager();
        EntityTransaction trans = em.getTransaction();
        try {
            trans.begin();
            Order order = em.find(Order.class, orderId);
            if (order != null) {
                order.setStatus(status);
                em.merge(order);
            }
            trans.commit();
        } catch (Exception e) {
            if (trans.isActive()) trans.rollback();
            e.printStackTrace();
        } finally {
            em.close();
        }
    }
}