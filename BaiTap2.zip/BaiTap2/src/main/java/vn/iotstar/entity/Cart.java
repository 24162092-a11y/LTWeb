package vn.iotstar.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import jakarta.persistence.*;

@Entity
@Table(name = "carts")
public class Cart implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "cart_id")
    private int cartId;

    @OneToOne
    @JoinColumn(name = "user_id")
    private User user;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date")
    private Date createdDate;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "updated_date")
    private Date updatedDate;

    // SỬA THÀNH EAGER: Bắt buộc Hibernate luôn tải kèm danh sách sản phẩm khi lấy Cart
    @OneToMany(mappedBy = "cart", cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
    private List<CartItem> items = new ArrayList<>();

    // Transients field để tránh lỗi khi gán TotalAmount nếu cần
    @Transient
    private double totalAmount;

    // Getters & Setters
    public int getCartId() { return cartId; }
    public void setCartId(int cartId) { this.cartId = cartId; }
    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }
    public Date getCreatedDate() { return createdDate; }
    public void setCreatedDate(Date createdDate) { this.createdDate = createdDate; }
    public Date getUpdatedDate() { return updatedDate; }
    public void setUpdatedDate(Date updatedDate) { this.updatedDate = updatedDate; }
    
    public List<CartItem> getItems() { return items; }
    public void setItems(List<CartItem> items) { this.items = items; }

    /**
     * Tính tổng tiền giỏ hàng
     */
    public double getTotalAmount() {
        double total = 0;
        if (items != null && !items.isEmpty()) {
            for (CartItem item : items) {
                double price = item.getPrice();
                if (price <= 0 && item.getProduct() != null) {
                    price = item.getProduct().getPrice();
                }
                total += price * item.getQuantity();
            }
        }
        return total;
    }

    public void setTotalAmount(double total) {
        this.totalAmount = total;
    }
}