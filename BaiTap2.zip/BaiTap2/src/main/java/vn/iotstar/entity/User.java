package vn.iotstar.entity;

import java.io.Serializable;
import java.util.Date;
import jakarta.persistence.*;

@Entity
@Table(name = "users")
@NamedQuery(name = "User.findAll", query = "SELECT u FROM User u")
public class User implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "username", columnDefinition = "NVARCHAR(50) NOT NULL UNIQUE")
    private String username;

    @Column(name = "email", columnDefinition = "NVARCHAR(100) NOT NULL UNIQUE")
    private String email;

    @Column(name = "password", columnDefinition = "NVARCHAR(255) NOT NULL")
    private String password;

    @Column(name = "fullname", columnDefinition = "NVARCHAR(100)")
    private String fullname;

    // --- 2 thuộc tính cho Profile ---
    @Column(name = "phone", columnDefinition = "VARCHAR(20)")
    private String phone;

    @Column(name = "images", columnDefinition = "NVARCHAR(500)")
    private String images;

    @Column(name = "status")
    private boolean status;

    @Column(name = "otp_code", columnDefinition = "VARCHAR(10)")
    private String otpCode;

    @Column(name = "otp_expiry")
    @Temporal(TemporalType.TIMESTAMP)
    private Date otpExpiry;

    @Column(name = "role", columnDefinition = "NVARCHAR(20) NOT NULL DEFAULT 'USER'")
    private String role = "USER";

    public User() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getFullname() { return fullname; }
    public void setFullname(String fullname) { this.fullname = fullname; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getImages() { return images; }
    public void setImages(String images) { this.images = images; }

    public boolean isStatus() { return status; }
    public void setStatus(boolean status) { this.status = status; }

    public String getOtpCode() { return otpCode; }
    public void setOtpCode(String otpCode) { this.otpCode = otpCode; }

    public Date getOtpExpiry() { return otpExpiry; }
    public void setOtpExpiry(Date otpExpiry) { this.otpExpiry = otpExpiry; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    // --- CÁC HÀM BỔ SUNG ĐỂ CHỐNG LỖI JSP 500 ---
    // Giúp JSP gọi ${account.roleId} hoặc ${account.roleid} đều không bị sập
    public int getRoleId() {
        if ("ADMIN".equalsIgnoreCase(this.role) || "1".equals(this.role)) {
            return 1;
        }
        return 2; // USER
    }

    public int getRoleid() {
        return getRoleId();
    }
}