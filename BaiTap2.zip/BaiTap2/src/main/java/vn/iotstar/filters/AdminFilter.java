package vn.iotstar.filters;

import java.io.IOException;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import vn.iotstar.entity.User;

@WebFilter(urlPatterns = {"/admin/*"})
public class AdminFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;
        HttpSession session = req.getSession(false);

        User account = (session != null) ? (User) session.getAttribute("account") : null;

        // Chưa đăng nhập -> về login
        if (account == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        // ADMIN được toàn quyền
        if ("ADMIN".equals(account.getRole())) {
            chain.doFilter(request, response);
            return;
        }

        // USER: chỉ cho phép GET (xem), chặn các method khác (POST, PUT, DELETE)
        String method = req.getMethod();
        if ("GET".equalsIgnoreCase(method)) {
            chain.doFilter(request, response);
            return;
        }

        // Chặn các thao tác thay đổi dữ liệu
        req.setAttribute("error", "Bạn không có quyền thực hiện thao tác này!");
        req.getRequestDispatcher("/views/access-denied.jsp").forward(req, resp);
    }
}