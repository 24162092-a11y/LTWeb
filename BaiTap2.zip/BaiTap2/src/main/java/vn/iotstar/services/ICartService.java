package vn.iotstar.services;

import vn.iotstar.entity.Cart;
import vn.iotstar.entity.User;

public interface ICartService {
    Cart getCartByUser(User user);
    void addToCart(User user, int productId, int quantity);
    void updateQuantity(User user, int productId, int quantity);
    void removeFromCart(User user, int productId);
    void clearCart(User user);
}