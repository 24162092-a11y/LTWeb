package vn.iotstar.services;

import vn.iotstar.entity.Order;
import vn.iotstar.entity.User;
import java.util.List;

public interface IOrderService {
    Order createOrder(User user, String shippingAddress, String note);
    Order findById(int orderId);
    List<Order> getOrdersByUser(User user);
    void updateStatus(int orderId, String status);
}