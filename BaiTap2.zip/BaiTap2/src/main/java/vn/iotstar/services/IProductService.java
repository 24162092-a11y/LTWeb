package vn.iotstar.services;

import java.util.List;
import vn.iotstar.entity.Product;

public interface IProductService {
    List<Product> findAll();
    Product findById(int id);
    void insert(Product product);
    void update(Product product);
    void delete(int id) throws Exception;

    List<Product> searchByName(String keyword);
    List<Product> findTop10();
    
   
    int count();
    List<Product> findAllPage(int page, int pageSize);
    List<Product> findAll(int page, int pageSize);
}