package vn.iotstar.services;

import vn.iotstar.entity.User;

public interface IUserService {
    boolean register(String username, String email, String password, String fullname);
    boolean verifyOTP(String email, String otp);
    User login(String username, String password);
    User findByEmail(String email);
    User findByUsername(String username);
    
    boolean sendForgotPasswordOTP(String email);
    boolean resetPassword(String email, String otp, String newPassword);
    
    
    void update(User user);
    User findById(int id);
}