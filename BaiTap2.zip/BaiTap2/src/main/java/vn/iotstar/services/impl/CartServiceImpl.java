package vn.iotstar.services.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import vn.iotstar.dao.ICartDao;
import vn.iotstar.dao.IProductDao;
import vn.iotstar.dao.impl.CartDao;
import vn.iotstar.dao.impl.ProductDao;
import vn.iotstar.entity.Cart;
import vn.iotstar.entity.CartItem;
import vn.iotstar.entity.Product;
import vn.iotstar.entity.User;
import vn.iotstar.services.ICartService;

public class CartServiceImpl implements ICartService {
    private ICartDao cartDao = new CartDao();
    private IProductDao productDao = new ProductDao();

    // Helper lấy ID của User an toàn
    private int getUserIdFromUser(User user) {
        if (user == null) return 0;
        try {
            return user.getId();
        } catch (NoSuchMethodError | Exception e) {
            try {
                return (int) user.getClass().getMethod("getUserId").invoke(user);
            } catch (Exception ex) {
                return 0;
            }
        }
    }

    @Override
    public Cart getCartByUser(User user) {
        if (user == null) return null;

        int userId = getUserIdFromUser(user);
        Cart cart = cartDao.findByUserId(userId);

        // 1. Nếu chưa có giỏ hàng trong CSDL -> Tạo mới
        if (cart == null) {
            cart = new Cart();
            cart.setUser(user);
            cart.setCreatedDate(new Date());
            cart.setUpdatedDate(new Date());
            
            cartDao.insert(cart);
            cart = cartDao.findByUserId(userId);
        }

        // 2. Đảm bảo danh sách items luôn đồng bộ
        if (cart != null) {
            // Lấy lại Cart chuẩn kèm items đã FETCH EAGER từ DAO
            Cart latestCart = cartDao.findByUserId(userId);
            if (latestCart != null && latestCart.getItems() != null) {
                cart.setItems(latestCart.getItems());
            }

            // Đảm bảo không bị null
            if (cart.getItems() == null) {
                cart.setItems(new ArrayList<>());
            }

            // Tính toán tổng tiền an toàn
            double total = 0;
            for (CartItem item : cart.getItems()) {
                double price = item.getPrice() > 0 ? item.getPrice() : (item.getProduct() != null ? item.getProduct().getPrice() : 0);
                total += price * item.getQuantity(); // Sử dụng getter getQuantity()
            }
            cart.setTotalAmount(total);
        }

        return cart;
    }

    @Override
    public void addToCart(User user, int productId, int quantity) {
        Cart cart = getCartByUser(user);
        if (cart == null) return;

        Product product = productDao.findById(productId);
        if (product == null) return;

        CartItem existingItem = cartDao.findCartItem(cart.getCartId(), productId);
        
        if (existingItem != null) {
            // Đã có -> Tăng số lượng
            existingItem.setQuantity(existingItem.getQuantity() + quantity);
            cartDao.updateCartItem(existingItem);
        } else {
            // Chưa có -> Tạo mới CartItem
            CartItem item = new CartItem();
            item.setCart(cart);
            item.setProduct(product);
            item.setQuantity(quantity);
            item.setPrice(product.getPrice());
            
            cartDao.insertCartItem(item);
        }
        
        // Cập nhật ngày sửa đổi giỏ hàng
        cart.setUpdatedDate(new Date());
        cartDao.update(cart);
    }

    @Override
    public void updateQuantity(User user, int productId, int quantity) {
        Cart cart = getCartByUser(user);
        if (cart == null) return;

        if (quantity <= 0) {
            removeFromCart(user, productId);
            return;
        }
        
        CartItem item = cartDao.findCartItem(cart.getCartId(), productId);
        if (item != null) {
            item.setQuantity(quantity);
            cartDao.updateCartItem(item);
            cart.setUpdatedDate(new Date());
            cartDao.update(cart);
        }
    }

    @Override
    public void removeFromCart(User user, int productId) {
        Cart cart = getCartByUser(user);
        if (cart != null) {
            cartDao.deleteCartItem(cart.getCartId(), productId);
            cart.setUpdatedDate(new Date());
            cartDao.update(cart);
        }
    }

    @Override
    public void clearCart(User user) {
        Cart cart = getCartByUser(user);
        if (cart != null) {
            cartDao.clearCartItems(cart.getCartId());
            cart.setUpdatedDate(new Date());
            cartDao.update(cart);
        }
    }
}