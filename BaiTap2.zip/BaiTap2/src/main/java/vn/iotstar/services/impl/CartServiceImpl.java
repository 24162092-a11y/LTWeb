package vn.iotstar.services.impl;

import java.util.Date;
import vn.iotstar.dao.ICartDao;
import vn.iotstar.dao.IProductDao;
import vn.iotstar.dao.impl.CartDao;
import vn.iotstar.dao.impl.ProductDao;
import vn.iotstar.entity.Cart;
import vn.iotstar.entity.CartItem;
import vn.iotstar.entity.Product;
import vn.iotstar.entity.User;
import vn.iotstar.services.ICartService;

public class CartServiceImpl implements ICartService {
    private ICartDao cartDao = new CartDao();
    private IProductDao productDao = new ProductDao();

    @Override
    public Cart getCartByUser(User user) {
        Cart cart = cartDao.findByUserId(user.getId());
        if (cart == null) {
            cart = new Cart();
            cart.setUser(user);
            cart.setCreatedDate(new Date());
            cart.setUpdatedDate(new Date());
            cartDao.insert(cart);
        }
        return cart;
    }

    @Override
    public void addToCart(User user, int productId, int quantity) {
        Cart cart = getCartByUser(user);
        Product product = productDao.findById(productId);
        if (product == null) return;

        CartItem existingItem = cartDao.findCartItem(cart.getCartId(), productId);
        if (existingItem != null) {
            existingItem.setQuantity(existingItem.getQuantity() + quantity);
            cartDao.updateCartItem(existingItem);
        } else {
            CartItem item = new CartItem();
            item.setCart(cart);
            item.setProduct(product);
            item.setQuantity(quantity);
            item.setPrice(product.getPrice());
            cartDao.insertCartItem(item);
        }
        cart.setUpdatedDate(new Date());
        cartDao.update(cart);
    }

    @Override
    public void updateQuantity(User user, int productId, int quantity) {
        Cart cart = getCartByUser(user);
        if (quantity <= 0) {
            removeFromCart(user, productId);
            return;
        }
        CartItem item = cartDao.findCartItem(cart.getCartId(), productId);
        if (item != null) {
            item.setQuantity(quantity);
            cartDao.updateCartItem(item);
            cart.setUpdatedDate(new Date());
            cartDao.update(cart);
        }
    }

    @Override
    public void removeFromCart(User user, int productId) {
        Cart cart = getCartByUser(user);
        cartDao.deleteCartItem(cart.getCartId(), productId);
        cart.setUpdatedDate(new Date());
        cartDao.update(cart);
    }

    @Override
    public void clearCart(User user) {
        Cart cart = getCartByUser(user);
        cartDao.clearCartItems(cart.getCartId());
        cart.setUpdatedDate(new Date());
        cartDao.update(cart);
    }
}