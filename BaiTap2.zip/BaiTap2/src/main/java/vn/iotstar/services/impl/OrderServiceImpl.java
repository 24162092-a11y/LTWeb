package vn.iotstar.services.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import vn.iotstar.dao.IOrderDao;
import vn.iotstar.dao.impl.OrderDao;
import vn.iotstar.entity.Cart;
import vn.iotstar.entity.CartItem;
import vn.iotstar.entity.Order;
import vn.iotstar.entity.OrderItem;
import vn.iotstar.entity.User;
import vn.iotstar.services.IOrderService;
import vn.iotstar.services.ICartService;

public class OrderServiceImpl implements IOrderService {
    private IOrderDao orderDao = new OrderDao();
    private ICartService cartService = new CartServiceImpl();

    @Override
    public Order createOrder(User user, String shippingAddress, String note) {
        Cart cart = cartService.getCartByUser(user);
        if (cart == null || cart.getItems() == null || cart.getItems().isEmpty()) {
            return null;
        }

        Order order = new Order();
        order.setUser(user);
        order.setOrderDate(new Date());
        order.setStatus("PENDING");
        order.setShippingAddress(shippingAddress);
        order.setNote(note);

        // Tính tổng tiền và tạo danh sách order items
        double total = 0;
        List<OrderItem> orderItems = new ArrayList<>();
        for (CartItem cartItem : cart.getItems()) {
            OrderItem item = new OrderItem();
            item.setProduct(cartItem.getProduct());
            item.setQuantity(cartItem.getQuantity());
            item.setPrice(cartItem.getPrice());
            orderItems.add(item);
            total += cartItem.getPrice() * cartItem.getQuantity();
        }
        order.setTotalAmount(total);

        // Lưu order vào DB
        orderDao.insert(order, orderItems);

        // Xóa giỏ hàng sau khi đặt hàng thành công
        cartService.clearCart(user);

        return order;
    }

    @Override
    public Order findById(int orderId) {
        return orderDao.findById(orderId);
    }

    @Override
    public List<Order> getOrdersByUser(User user) {
        return orderDao.findByUserId(user.getId());
    }

    @Override
    public void updateStatus(int orderId, String status) {
        orderDao.updateStatus(orderId, status);
    }
}