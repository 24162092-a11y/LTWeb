package vn.iotstar.services.impl;

import java.util.Date;
import java.util.Random;
import vn.iotstar.dao.IUserDao;
import vn.iotstar.dao.impl.UserDao;
import vn.iotstar.entity.User;
import vn.iotstar.services.IUserService;
import vn.iotstar.utils.EmailUtil;

public class UserServiceImpl implements IUserService {

    private IUserDao userDao = new UserDao();

    @Override
    public boolean register(String username, String email, String password, String fullname) {
        if (userDao.findByUsername(username) != null || userDao.findByEmail(email) != null) {
            return false;
        }

        String otp = String.format("%06d", new Random().nextInt(999999));
        Date expiry = new Date(System.currentTimeMillis() + 5 * 60 * 1000); 

        User user = new User();
        user.setUsername(username);
        user.setEmail(email);
        user.setPassword(password);
        user.setFullname(fullname);
        user.setStatus(false);
        user.setOtpCode(otp);
        user.setOtpExpiry(expiry);

        userDao.insert(user);

        // Gửi Mail OTP
        String body = "<h3>Mã OTP kích hoạt tài khoản của bạn là: <b style='color:red;'>" + otp + "</b></h3>"
                    + "<p>Mã này có hiệu lực trong 5 phút.</p>";
        EmailUtil.sendEmail(email, "Xác nhận đăng ký tài khoản", body);

        return true;
    }

    @Override
    public boolean verifyOTP(String email, String otp) {
        User user = userDao.findByEmail(email);
        if (user != null && user.getOtpCode() != null && user.getOtpCode().equals(otp)) {
            if (user.getOtpExpiry().after(new Date())) {
                user.setStatus(true);
                user.setOtpCode(null);
                user.setOtpExpiry(null);
                userDao.update(user);
                return true;
            }
        }
        return false;
    }

    @Override
    public User login(String username, String password) {
        User user = userDao.findByUsername(username);
        if (user != null && user.getPassword().equals(password) && user.isStatus()) {
            return user;
        }
        return null;
    }

    @Override
    public User findByEmail(String email) {
        return userDao.findByEmail(email);
    }

    @Override
    public User findByUsername(String username) {
        return userDao.findByUsername(username);
    }

    @Override
    public boolean sendForgotPasswordOTP(String email) {
        User user = userDao.findByEmail(email);
        if (user == null) {
            return false;
        }

        String otp = String.format("%06d", new Random().nextInt(999999));
        Date expiry = new Date(System.currentTimeMillis() + 5 * 60 * 1000); // Hạn 5 phút

        user.setOtpCode(otp);
        user.setOtpExpiry(expiry);
        userDao.update(user);

        String body = "<h3>Mã OTP khôi phục mật khẩu của bạn là: <b style='color:red;'>" + otp + "</b></h3>"
                    + "<p>Mã này có hiệu lực trong 5 phút.</p>";
        EmailUtil.sendEmail(email, "Khôi phục mật khẩu", body);

        return true;
    }

    @Override
    public boolean resetPassword(String email, String otp, String newPassword) {
        User user = userDao.findByEmail(email);
        if (user != null && user.getOtpCode() != null && user.getOtpCode().equals(otp)) {
            if (user.getOtpExpiry().after(new Date())) {
                user.setPassword(newPassword);
                user.setOtpCode(null);
                user.setOtpExpiry(null);
                userDao.update(user);
                return true;
            }
        }
        return false;
    }


    @Override
    public void update(User user) {
        userDao.update(user);
    }

    @Override
    public User findById(int id) {
        return userDao.findById(id);
    }
}