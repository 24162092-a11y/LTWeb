package vn.iotstar.utils;

import jakarta.servlet.http.Part;
import java.io.File;
import java.nio.file.Paths;

public class UploadUtils {

    /**
     * Xử lý lưu file upload vào thư mục chỉ định
     * @param filePart Đối tượng file nhận từ request.getPart()
     * @param uploadPath Đường dẫn thư mục lưu file (ví dụ Constant.UPLOAD_DIR)
     * @return Tên file mới lưu trong database, hoặc null nếu không có file
     */
    public static String processUpload(Part filePart, String uploadPath) {
        if (filePart == null || filePart.getSize() == 0 || filePart.getSubmittedFileName() == null) {
            return null;
        }

        try {
      
            File uploadDir = new File(uploadPath);
            if (!uploadDir.exists()) {
                uploadDir.mkdirs();
            }

            
            String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();

            
            String newFileName = System.currentTimeMillis() + "_" + fileName;

            
            filePart.write(uploadPath + File.separator + newFileName);

            return newFileName;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}