<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<head>
    <title>Thêm danh mục mới</title>
    <style>
        .form-card-container {
            max-width: 600px;
            margin: 20px auto;
        }
        .card-custom {
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
            border: none;
        }
        .card-header-custom {
            background: #4e73df;
            color: white;
            border-radius: 16px 16px 0 0 !important;
            padding: 16px 20px;
        }
        .btn-primary-custom {
            background-color: #4e73df;
            border: none;
        }
        .btn-primary-custom:hover {
            background-color: #224abe;
        }
    </style>
</head>

<div class="container form-card-container">
    <div class="card card-custom">
        <div class="card-header card-header-custom">
            <h4 class="mb-0 fw-bold">📝 Thêm danh mục mới</h4>
        </div>
        <div class="card-body p-4">
            <c:if test="${not empty error}">
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i>${error}
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            </c:if>

            <form action="<c:url value='/admin/category/insert'/>" method="post" enctype="multipart/form-data">
                
                <div class="mb-3">
                    <label for="categoryname" class="form-label fw-semibold">Tên danh mục <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="categoryname" name="categoryname" placeholder="Nhập tên danh mục" required>
                </div>

                <div class="mb-3">
                    <label for="images1" class="form-label fw-semibold">Tải ảnh lên <span class="text-danger">*</span></label>
                    <input type="file" class="form-control" id="images1" name="images1" accept="image/*" required>
                    <div class="form-text">Chọn ảnh từ máy tính (hỗ trợ jpg, png, gif)</div>
                </div>

                <div class="mb-4">
                    <label class="form-label fw-semibold">Trạng thái</label><br>
                    <div class="form-check form-check-inline me-4">
                        <input class="form-check-input" type="radio" name="status" id="statusActive" value="1" checked>
                        <label class="form-check-label" for="statusActive">Hoạt động</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="status" id="statusInactive" value="0">
                        <label class="form-check-label" for="statusInactive">Khóa</label>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary-custom text-white w-100 py-2 fw-bold shadow-sm">
                    THÊM MỚI
                </button>
            </form>
            <div class="mt-3 text-center">
                <a href="<c:url value='/admin/categories'/>" class="text-decoration-none text-secondary">
                    <i class="bi bi-arrow-left me-1"></i> Quay lại danh sách
                </a>
            </div>
        </div>
    </div>
</div>