<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>

<head>
    <title>Sửa danh mục</title>
    <style>
        .form-card-container {
            max-width: 600px;
            margin: 20px auto;
        }
        .card-custom {
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
            border: none;
        }
        .card-header-custom {
            background: #f6c23e;
            color: #333;
            border-radius: 16px 16px 0 0 !important;
            padding: 16px 20px;
        }
        .btn-warning-custom {
            background-color: #f6c23e;
            border: none;
            color: #333;
        }
        .btn-warning-custom:hover {
            background-color: #dda20a;
            color: #000;
        }
        .img-preview {
            max-width: 150px;
            max-height: 120px;
            object-fit: cover;
            margin-top: 5px;
            border: 1px solid #ddd;
            border-radius: 8px;
        }
    </style>
</head>

<div class="container form-card-container">
    <div class="card card-custom">
        <div class="card-header card-header-custom">
            <h4 class="mb-0 fw-bold">✏️ Sửa danh mục</h4>
        </div>
        <div class="card-body p-4">
            <!-- Hiển thị lỗi nếu có -->
            <c:if test="${not empty error}">
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i>${error}
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            </c:if>

            <form action="<c:url value='/admin/category/update'/>" method="post" enctype="multipart/form-data">
                
                <input type="hidden" name="categoryid" value="${cate.categoryId}">

                <div class="mb-3">
                    <label for="categoryname" class="form-label fw-semibold">Tên danh mục <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="categoryname" name="categoryname" value="${cate.categoryname}" required>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Ảnh hiện tại</label><br>
                    <c:choose>
                        <c:when test="${not empty cate.images && fn:startsWith(cate.images, 'http')}">
                            <c:url value="${cate.images}" var="imgUrl" />
                        </c:when>
                        <c:otherwise>
                            <c:url value="/image?fname=${cate.images}" var="imgUrl" />
                        </c:otherwise>
                    </c:choose>
                    <img src="${imgUrl}" class="img-preview shadow-sm" alt="Current Image" onerror="this.style.display='none';" />
                </div>

                <div class="mb-3">
                    <label for="images1" class="form-label fw-semibold">Tải ảnh mới (để trống nếu không thay đổi)</label>
                    <input type="file" class="form-control" id="images1" name="images1" accept="image/*">
                </div>

                <div class="mb-4">
                    <label class="form-label fw-semibold">Trạng thái</label><br>
                    <div class="form-check form-check-inline me-4">
                        <input class="form-check-input" type="radio" name="status" id="statusActive" value="1" ${cate.status == 1 ? 'checked' : ''}>
                        <label class="form-check-label" for="statusActive">Hoạt động</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="status" id="statusInactive" value="0" ${cate.status != 1 ? 'checked' : ''}>
                        <label class="form-check-label" for="statusInactive">Khóa</label>
                    </div>
                </div>

                <button type="submit" class="btn btn-warning-custom w-100 py-2 fw-bold shadow-sm">
                    CẬP NHẬT
                </button>
            </form>
            <div class="mt-3 text-center">
                <a href="<c:url value='/admin/categories'/>" class="text-decoration-none text-secondary">
                    <i class="bi bi-arrow-left me-1"></i> Quay lại danh sách
                </a>
            </div>
        </div>
    </div>
</div>