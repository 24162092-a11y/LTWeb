<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>

<head>
    <title>Danh sách danh mục</title>
    <style>
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            flex-wrap: wrap;
        }
        .category-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 20px;
        }
        .category-card {
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            transition: transform 0.2s, box-shadow 0.2s;
            display: flex;
            flex-direction: column;
        }
        .category-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.12);
        }
        .category-image {
            width: 100%;
            aspect-ratio: 1 / 1;
            background: #f0f0f0;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
        }
        .category-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .no-image-placeholder {
            width: 100%;
            height: 100%;
            background: #e9ecef;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #aaa;
            font-size: 14px;
        }
        .category-info {
            padding: 12px 14px 16px;
            flex: 1;
            display: flex;
            flex-direction: column;
        }
        .category-name {
            font-size: 16px;
            font-weight: 600;
            color: #222;
            margin-bottom: 6px;
        }
        .category-status {
            font-size: 13px;
            margin-bottom: 10px;
        }
        .category-actions {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
            margin-top: auto;
        }
        .btn-sm-custom {
            font-size: 12px;
            padding: 4px 10px;
            border-radius: 6px;
        }
        @media (max-width: 576px) {
            .category-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 12px;
            }
        }
    </style>
</head>

<div class="container my-3">
    <div class="section-header">
        <h2 class="mb-0">📂 Danh sách danh mục</h2>
        <c:if test="${sessionScope.account.role == 'ADMIN'}">
            <a href="<c:url value='/admin/category/add'/>" class="btn btn-primary">
                <i class="bi bi-plus-lg"></i> Thêm danh mục
            </a>
        </c:if>
    </div>

    <!-- Hiển thị lỗi -->
    <c:if test="${not empty error}">
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="bi bi-exclamation-triangle-fill"></i> ${error}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    </c:if>

    <div class="category-grid">
        <c:forEach items="${listcate}" var="cate">
            <div class="category-card">
                <!-- Hình ảnh -->
                <div class="category-image">
                    <c:choose>
                        <c:when test="${not empty cate.images}">
                            <c:choose>
                                <c:when test="${fn:startsWith(cate.images, 'http')}">
                                    <img src="${cate.images}" alt="${cate.categoryname}"
                                         onerror="this.onerror=null; this.src='${pageContext.request.contextPath}/assets/img/no-image.png';" />
                                </c:when>
                                <c:otherwise>
                                    <img src="${pageContext.request.contextPath}/image?fname=${cate.images}" alt="${cate.categoryname}"
                                         onerror="this.onerror=null; this.src='${pageContext.request.contextPath}/assets/img/no-image.png';" />
                                </c:otherwise>
                            </c:choose>
                        </c:when>
                        <c:otherwise>
                            <div class="no-image-placeholder">
                                <i class="bi bi-folder" style="font-size: 32px;"></i>
                            </div>
                        </c:otherwise>
                    </c:choose>
                </div>
                <!-- Thông tin -->
                <div class="category-info">
                    <div class="category-name">${cate.categoryname}</div>
                    <div class="category-status">
                        <c:choose>
                            <c:when test="${cate.status == 1}">
                                <span class="badge bg-success">Hoạt động</span>
                            </c:when>
                            <c:otherwise>
                                <span class="badge bg-secondary">Khóa</span>
                            </c:otherwise>
                        </c:choose>
                    </div>
                    <!-- Hành động (chỉ ADMIN) -->
                    <div class="category-actions">
                        <c:if test="${sessionScope.account.role == 'ADMIN'}">
                            <a href="<c:url value='/admin/category/edit?id=${cate.categoryId}'/>" class="btn btn-warning btn-sm-custom">
                                <i class="bi bi-pencil"></i> Sửa
                            </a>
                            <a href="<c:url value='/admin/category/delete?id=${cate.categoryId}'/>" 
                               class="btn btn-danger btn-sm-custom" 
                               onclick="return confirm('Bạn có chắc chắn muốn xóa?');">
                               <i class="bi bi-trash"></i> Xóa
                            </a>
                        </c:if>
                        <c:if test="${sessionScope.account.role != 'ADMIN'}">
                            <span class="text-muted small"><i class="bi bi-eye"></i> Chỉ xem</span>
                        </c:if>
                    </div>
                </div>
            </div>
        </c:forEach>
        <c:if test="${empty listcate}">
            <div class="col-12 text-center py-5">
                <i class="bi bi-folder-open" style="font-size: 48px; color: #ccc;"></i>
                <p class="text-muted mt-2">Chưa có danh mục nào.</p>
            </div>
        </c:if>
    </div>
</div>