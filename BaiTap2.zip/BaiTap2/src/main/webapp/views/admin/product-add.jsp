<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<head>
    <title>Thêm sản phẩm mới</title>
    <style>
        .form-card-container {
            max-width: 600px;
            margin: 20px auto;
        }
        .card-custom {
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
            border: none;
        }
        .card-header-custom {
            background: #4e73df;
            color: white;
            border-radius: 16px 16px 0 0 !important;
            padding: 16px 20px;
        }
        .btn-primary-custom {
            background-color: #4e73df;
            border: none;
        }
        .btn-primary-custom:hover {
            background-color: #224abe;
        }
    </style>
</head>

<div class="container form-card-container">
    <div class="card card-custom">
        <div class="card-header card-header-custom">
            <h4 class="mb-0 fw-bold">📝 Thêm sản phẩm mới</h4>
        </div>
        <div class="card-body p-4">
            
            <c:if test="${not empty error}">
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i>${error}
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            </c:if>

            <form action="${pageContext.request.contextPath}/admin/product/insert" method="post" enctype="multipart/form-data">
                
                <div class="mb-3">
                    <label class="form-label fw-semibold">Tên sản phẩm <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" name="productName" placeholder="Nhập tên sản phẩm" required>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Giá (VNĐ) <span class="text-danger">*</span></label>
                    <input type="number" step="1000" class="form-control" name="price" placeholder="Nhập giá sản phẩm" required>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Tải ảnh lên <span class="text-danger">*</span></label>
                    <input type="file" class="form-control" name="images" accept="image/*" required>
                    <div class="form-text">Chọn ảnh từ máy tính (jpg, png, gif, webp)</div>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Mô tả</label>
                    <textarea class="form-control" name="description" rows="4" placeholder="Nhập mô tả chi tiết..."></textarea>
                </div>

                <div class="mb-4">
                    <label class="form-label fw-semibold">Danh mục <span class="text-danger">*</span></label>
                    <select class="form-select" name="categoryId" required>
                        <option value="" disabled selected>-- Chọn danh mục --</option>
                        <c:forEach items="${categories}" var="c">
                            <option value="${c.categoryId}">${c.categoryname}</option>
                        </c:forEach>
                    </select>
                </div>

                <button type="submit" class="btn btn-primary-custom text-white w-100 py-2 fw-bold shadow-sm">
                    THÊM MỚI
                </button>
            </form>

            <div class="mt-3 text-center">
                <a href="${pageContext.request.contextPath}/admin/products" class="text-decoration-none text-secondary">
                    <i class="bi bi-arrow-left me-1"></i> Quay lại danh sách
                </a>
            </div>
        </div>
    </div>
</div>