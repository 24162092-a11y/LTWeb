<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>

<title>Sửa sản phẩm</title>

<style>
    .form-card-container {
        max-width: 600px;
        margin: 20px auto;
    }
    .card-custom {
        border-radius: 16px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.08);
        border: none;
    }
    .card-header-custom {
        background: #f6c23e;
        color: #333;
        border-radius: 16px 16px 0 0 !important;
        padding: 16px 20px;
    }
    .btn-warning-custom {
        background-color: #f6c23e;
        border: none;
        color: #333;
    }
    .btn-warning-custom:hover {
        background-color: #dda20a;
        color: #000;
    }
    .img-preview {
        max-width: 150px;
        max-height: 120px;
        object-fit: cover;
        margin-top: 5px;
        border: 1px solid #ddd;
        border-radius: 8px;
    }
</style>

<div class="container form-card-container">
    <div class="card card-custom">
        <div class="card-header card-header-custom">
            <h4 class="mb-0 fw-bold">✏️ Sửa sản phẩm</h4>
        </div>
        <div class="card-body p-4">
            
            <c:if test="${not empty error}">
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i>${error}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            </c:if>

            <form action="${pageContext.request.contextPath}/admin/product/update" 
                  method="post" 
                  enctype="multipart/form-data" 
                  class="needs-validation" 
                  novalidate>
                
                <input type="hidden" name="productId" value="${product.productId != null ? product.productId : product.id}">
                <input type="hidden" name="id" value="${product.productId != null ? product.productId : product.id}">

                <div class="mb-3">
                    <label class="form-label fw-semibold">Tên sản phẩm <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" name="productName" value="${product.productName}" required minlength="3">
                    <div class="invalid-feedback">Tên sản phẩm phải có tối thiểu 3 ký tự.</div>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Giá (VNĐ) <span class="text-danger">*</span></label>
                    <input type="number" step="1000" class="form-control" name="price" value="${product.price}" required min="1000">
                    <div class="invalid-feedback">Giá sản phẩm phải từ 1,000 VNĐ trở lên.</div>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Ảnh hiện tại</label><br>
                    <c:choose>
                        <c:when test="${not empty product.images && fn:startsWith(product.images, 'http')}">
                            <img src="${product.images}" class="img-preview shadow-sm" alt="Current Image" />
                        </c:when>
                        <c:when test="${not empty product.images}">
                            <img src="${pageContext.request.contextPath}/image?fname=${product.images}" class="img-preview shadow-sm" alt="Current Image" />
                        </c:when>
                        <c:otherwise>
                            <span class="text-muted small">Chưa có ảnh</span>
                        </c:otherwise>
                    </c:choose>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Tải ảnh mới (để trống nếu không thay đổi)</label>
                    <input type="file" class="form-control" name="images" accept="image/*">
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Mô tả</label>
                    <textarea class="form-control" name="description" rows="4">${product.description}</textarea>
                </div>

                <div class="mb-4">
                    <label class="form-label fw-semibold">Danh mục <span class="text-danger">*</span></label>
                    <select class="form-select" name="categoryId" required>
                        <c:forEach items="${categories}" var="c">
                            <option value="${c.categoryId != null ? c.categoryId : c.id}" 
                                ${(c.categoryId == product.category.categoryId || c.id == product.category.id) ? 'selected' : ''}>
                                ${c.categoryName != null ? c.categoryName : (c.categoryname != null ? c.categoryname : c.name)}
                            </option>
                        </c:forEach>
                    </select>
                    <div class="invalid-feedback">Vui lòng chọn danh mục cho sản phẩm.</div>
                </div>

                <button type="submit" class="btn btn-warning-custom w-100 py-2 fw-bold shadow-sm">
                    CẬP NHẬT
                </button>
            </form>

            <div class="mt-3 text-center">
                <a href="${pageContext.request.contextPath}/admin/products" class="text-decoration-none text-secondary">
                    <i class="bi bi-arrow-left me-1"></i> Quay lại danh sách
                </a>
            </div>
        </div>
    </div>
</div>