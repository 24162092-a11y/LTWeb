<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>

<title>Danh sách sản phẩm - Admin</title>

<style>
    .section-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 24px;
        flex-wrap: wrap;
    }
    .product-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 24px;
    }
    @media (max-width: 992px) {
        .product-grid { grid-template-columns: repeat(2, 1fr); }
    }
    @media (max-width: 576px) {
        .product-grid { grid-template-columns: repeat(1, 1fr); }
    }
    .product-card {
        background: #ffffff;
        border-radius: 16px;
        border: 1px solid #f0f0f0;
        overflow: hidden;
        box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        transition: all 0.3s ease;
        display: flex;
        flex-direction: column;
    }
    .product-card:hover {
        transform: translateY(-6px);
        box-shadow: 0 12px 25px rgba(0,0,0,0.1);
    }
    .product-image {
        width: 100%;
        height: 220px;
        background: #fafafa;
        display: flex;
        align-items: center;
        justify-content: center;
        overflow: hidden;
        padding: 12px;
    }
    .product-image img {
        max-width: 100%;
        max-height: 100%;
        object-fit: contain;
    }
    .product-info {
        padding: 16px;
        flex: 1;
        display: flex;
        flex-direction: column;
    }
    .product-name {
        font-size: 15px;
        font-weight: 600;
        color: #2c3e50;
        margin-bottom: 8px;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
        height: 2.8em;
        line-height: 1.4;
    }
    .product-price {
        font-size: 18px;
        font-weight: 700;
        color: #d9534f;
        margin-bottom: 14px;
    }
    .product-actions {
        display: flex;
        gap: 10px;
        margin-top: auto;
    }
    .btn-custom {
        flex: 1;
        padding: 8px 12px;
        font-size: 13px;
        font-weight: 600;
        border-radius: 8px;
        text-align: center;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 4px;
    }
</style>

<div class="container my-4">
    <div class="section-header">
        <h2 class="fw-bold mb-0">🛍️ Quản lý sản phẩm</h2>
        <a href="${pageContext.request.contextPath}/admin/product/add" class="btn btn-primary fw-bold px-3 py-2 shadow-sm">
            ➕ Thêm sản phẩm mới
        </a>
    </div>

    <c:if test="${not empty sessionScope.error}">
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            ${sessionScope.error}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <% session.removeAttribute("error"); %>
    </c:if>
    <c:if test="${not empty sessionScope.message}">
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            ${sessionScope.message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <% session.removeAttribute("message"); %>
    </c:if>

    <div class="product-grid">
        <c:forEach items="${productList}" var="p">
            <c:set var="currentId" value="${not empty p.productId ? p.productId : p.id}" />

            <div class="product-card">
                <div class="product-image">
                    <c:choose>
                        <c:when test="${not empty p.images && fn:startsWith(p.images, 'http')}">
                            <img src="${p.images}" alt="${p.productName}" />
                        </c:when>
                        <c:when test="${not empty p.images}">
                            <img src="${pageContext.request.contextPath}/image?fname=${p.images}" alt="${p.productName}" />
                        </c:when>
                        <c:otherwise>
                            <img src="https://via.placeholder.com/200" alt="No Image" />
                        </c:otherwise>
                    </c:choose>
                </div>

                <div class="product-info">
                    <div class="product-name" title="${p.productName}">${p.productName}</div>
                    <div class="product-price">
                        <fmt:formatNumber value="${p.price}" type="number" groupingUsed="true" /> đ
                    </div>

                    <div class="product-actions">
                        <a href="${pageContext.request.contextPath}/admin/product/edit?id=${currentId}" class="btn btn-warning btn-custom text-dark fw-bold">
                            ✏️ Sửa
                        </a>
                        <a href="${pageContext.request.contextPath}/admin/product/delete?id=${currentId}" 
                           class="btn btn-danger btn-custom text-white fw-bold" 
                           onclick="return confirm('Bạn có chắc muốn xóa sản phẩm này?')">
                            🗑️ Xóa
                        </a>
                    </div>
                </div>
            </div>
        </c:forEach>
    </div>

    <c:if test="${empty productList}">
        <div class="text-center py-5">
            <p class="text-muted fs-5">Chưa có sản phẩm nào trong hệ thống.</p>
        </div>
    </c:if>

    <c:if test="${totalPages > 1}">
        <nav class="mt-5">
            <ul class="pagination justify-content-center">
                <li class="page-item ${currentPage == 1 ? 'disabled' : ''}">
                    <a class="page-link" href="${pageContext.request.contextPath}/admin/products?page=${currentPage - 1}">Trước</a>
                </li>
                <c:forEach begin="1" end="${totalPages}" var="i">
                    <li class="page-item ${currentPage == i ? 'active' : ''}">
                        <a class="page-link" href="${pageContext.request.contextPath}/admin/products?page=${i}">${i}</a>
                    </li>
                </c:forEach>
                <li class="page-item ${currentPage == totalPages ? 'disabled' : ''}">
                    <a class="page-link" href="${pageContext.request.contextPath}/admin/products?page=${currentPage + 1}">Sau</a>
                </li>
            </ul>
        </nav>
    </c:if>
</div>