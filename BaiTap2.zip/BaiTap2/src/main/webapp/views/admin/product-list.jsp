<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>

<head>
    <title>Danh sách sản phẩm</title>
    <style>
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            flex-wrap: wrap;
        }
        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(230px, 1fr));
            gap: 20px;
        }
        .product-card {
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            transition: transform 0.2s, box-shadow 0.2s;
            display: flex;
            flex-direction: column;
        }
        .product-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.12);
        }
        .product-image {
            width: 100%;
            aspect-ratio: 1 / 1;
            background: #f0f0f0;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
        }
        .product-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .no-image-placeholder {
            width: 100%;
            height: 100%;
            background: #e9ecef;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #aaa;
            font-size: 14px;
        }
        .product-info {
            padding: 12px 14px 16px;
            flex: 1;
            display: flex;
            flex-direction: column;
        }
        .product-name {
            font-size: 14px;
            font-weight: 500;
            color: #222;
            margin-bottom: 6px;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
            text-overflow: ellipsis;
            line-height: 1.4;
            height: 2.8em;
        }
        .product-price {
            font-size: 18px;
            font-weight: 700;
            color: #ee4d2d;
            margin-bottom: 8px;
        }
        .product-actions {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
            margin-top: auto;
            align-items: center;
        }
        .btn-sm-custom {
            font-size: 12px;
            padding: 4px 10px;
            border-radius: 6px;
        }
        .quick-price-form {
            display: flex;
            gap: 4px;
            margin-top: 6px;
            width: 100%;
        }
        .quick-price-form input {
            flex: 1;
            padding: 2px 6px;
            font-size: 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            min-width: 60px;
        }
        .quick-price-form button {
            padding: 2px 8px;
            font-size: 11px;
            white-space: nowrap;
        }
        @media (max-width: 576px) {
            .product-grid { grid-template-columns: repeat(2, 1fr); gap: 12px; }
            .quick-price-form input { min-width: 50px; }
        }
    </style>
</head>

<div class="container my-3">
    <div class="section-header">
        <h2 class="mb-0">🛍️ Danh sách sản phẩm</h2>
        
        <!-- Sửa điều kiện kiểm tra ADMIN linh hoạt hơn -->
        <c:if test="${sessionScope.account != null && (sessionScope.account.role == 'ADMIN' || sessionScope.account.roleid == 1 || sessionScope.account.roleId == 1)}">
            <a href="${pageContext.request.contextPath}/admin/product/add" class="btn btn-primary fw-bold">
                <i class="bi bi-plus-lg"></i> ➕ Thêm sản phẩm
            </a>
        </c:if>
    </div>

    <!-- Thông báo lỗi / thành công -->
    <c:if test="${not empty sessionScope.error}">
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="bi bi-exclamation-triangle-fill"></i> ${sessionScope.error}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <% session.removeAttribute("error"); %>
    </c:if>
    <c:if test="${not empty sessionScope.message}">
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill"></i> ${sessionScope.message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <% session.removeAttribute("message"); %>
    </c:if>

    <div class="product-grid">
        <c:forEach items="${productList}" var="p">
            <!-- Tự động lấy đúng ID của sản phẩm -->
            <c:set var="currentId" value="${not empty p.productId ? p.productId : p.id}" />

            <div class="product-card">
                <!-- Hình ảnh -->
                <div class="product-image">
                    <c:choose>
                        <c:when test="${not empty p.images}">
                            <c:choose>
                                <c:when test="${fn:startsWith(p.images, 'http')}">
                                    <img src="${p.images}" alt="${p.productName}"
                                         onerror="this.onerror=null; this.src='https://via.placeholder.com/300';" />
                                </c:when>
                                <c:otherwise>
                                    <img src="${pageContext.request.contextPath}/image?fname=${p.images}" alt="${p.productName}"
                                         onerror="this.onerror=null; this.src='https://via.placeholder.com/300';" />
                                </c:otherwise>
                            </c:choose>
                        </c:when>
                        <c:otherwise>
                            <div class="no-image-placeholder">
                                <i class="bi bi-image" style="font-size: 32px;"></i>
                            </div>
                        </c:otherwise>
                    </c:choose>
                </div>

                <!-- Thông tin -->
                <div class="product-info">
                    <div class="product-name">${p.productName}</div>
                    <div class="product-price">
                        <fmt:formatNumber value="${p.price}" type="number" groupingUsed="true" /> đ
                    </div>

                    <!-- Hành động -->
                    <div class="product-actions">
                        <c:choose>
                            <%-- Nhánh dành cho ADMIN --%>
                            <c:when test="${sessionScope.account != null && (sessionScope.account.role == 'ADMIN' || sessionScope.account.roleid == 1 || sessionScope.account.roleId == 1)}">
                                <a href="${pageContext.request.contextPath}/admin/product/edit?id=${currentId}" class="btn btn-warning btn-sm-custom fw-bold">
                                    ✏️ Sửa
                                </a>
                                <a href="${pageContext.request.contextPath}/admin/product/delete?id=${currentId}" 
                                   class="btn btn-danger btn-sm-custom fw-bold" 
                                   onclick="return confirm('Bạn có chắc muốn xóa sản phẩm này?')">
                                   🗑️ Xóa
                                </a>
                                <!-- Form chỉnh giá nhanh -->
                                <form action="${pageContext.request.contextPath}/admin/product/update-price" method="post" class="quick-price-form">
                                    <input type="hidden" name="productId" value="${currentId}">
                                    <input type="number" step="1000" name="price" value="${p.price}" required>
                                    <button type="submit" class="btn btn-outline-primary btn-sm-custom">
                                        ✔ Cập nhật
                                    </button>
                                </form>
                            </c:when>

                            <%-- Nhánh dành cho USER / Khách chưa đăng nhập --%>
                            <c:otherwise>
                                <a href="${pageContext.request.contextPath}/cart/add?productId=${currentId}" class="btn btn-success btn-sm-custom fw-bold">
                                    🛒 Mua
                                </a>
                                <a href="${pageContext.request.contextPath}/product/detail?id=${currentId}" class="btn btn-outline-secondary btn-sm-custom">
                                    🔍 Chi tiết
                                </a>
                            </c:otherwise>
                        </c:choose>
                    </div>
                </div>
            </div>
        </c:forEach>

        <c:if test="${empty productList}">
            <div class="col-12 text-center py-5">
                <i class="bi bi-box-seam" style="font-size: 48px; color: #ccc;"></i>
                <p class="text-muted mt-2">Chưa có sản phẩm nào.</p>
            </div>
        </c:if>
    </div>
</div>