<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Giỏ hàng của bạn</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        body { background: #f5f5fa; }
        .container { margin-top: 30px; }
        .cart-item { border-bottom: 1px solid #ddd; padding: 15px 0; }
        .cart-item:last-child { border-bottom: none; }
        .quantity-input { width: 60px; text-align: center; }
    </style>
</head>
<body>
<%@ include file="/views/common/header.jsp" %>

<div class="container">
    <h2><i class="bi bi-cart"></i> Giỏ hàng của bạn</h2>

    <c:if test="${not empty sessionScope.message}">
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            ${sessionScope.message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <% session.removeAttribute("message"); %>
    </c:if>
    <c:if test="${not empty sessionScope.error}">
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            ${sessionScope.error}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <% session.removeAttribute("error"); %>
    </c:if>

    <c:set var="cart" value="${requestScope.cart}" />
    <c:if test="${empty cart or empty cart.items}">
        <div class="alert alert-info">Giỏ hàng trống.</div>
        <a href="${pageContext.request.contextPath}/admin/products" class="btn btn-primary">Tiếp tục mua sắm</a>
    </c:if>

    <c:if test="${not empty cart and not empty cart.items}">
        <div class="card">
            <div class="card-body">
                <c:forEach items="${cart.items}" var="item">
                    <div class="cart-item row align-items-center">
                        <div class="col-md-4">
                            <strong>${item.product.productName}</strong>
                        </div>
                        <div class="col-md-2">
                            <fmt:formatNumber value="${item.price}" type="number" groupingUsed="true" /> đ
                        </div>
                        <div class="col-md-2">
                            <form action="${pageContext.request.contextPath}/cart/update" method="post" class="d-inline">
                                <input type="hidden" name="productId" value="${item.product.productId}">
                                <input type="number" name="quantity" value="${item.quantity}" min="1" class="quantity-input" onchange="this.form.submit()">
                            </form>
                        </div>
                        <div class="col-md-2">
                            <fmt:formatNumber value="${item.price * item.quantity}" type="number" groupingUsed="true" /> đ
                        </div>
                        <div class="col-md-2 text-end">
                            <a href="${pageContext.request.contextPath}/cart/remove?productId=${item.product.productId}" class="btn btn-danger btn-sm" onclick="return confirm('Xóa sản phẩm?')">
                                <i class="bi bi-trash"></i>
                            </a>
                        </div>
                    </div>
                </c:forEach>

                <div class="row mt-3">
                    <div class="col-md-6">
                        <a href="${pageContext.request.contextPath}/cart/clear" class="btn btn-outline-danger" onclick="return confirm('Xóa toàn bộ giỏ hàng?')">Xóa tất cả</a>
                    </div>
                    <div class="col-md-6 text-end">
                        <h4>Tổng tiền: <fmt:formatNumber value="${cart.totalAmount}" type="number" groupingUsed="true" /> đ</h4>
                        <a href="${pageContext.request.contextPath}/cart/checkout" class="btn btn-success">Thanh toán</a>
                    </div>
                </div>
            </div>
        </div>
    </c:if>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>