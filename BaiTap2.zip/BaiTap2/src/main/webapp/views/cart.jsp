<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>

<head>
    <title>Giỏ hàng của bạn</title>
    <style>
        .cart-item { border-bottom: 1px solid #ddd; padding: 15px 0; }
        .cart-item:last-child { border-bottom: none; }
        .quantity-input { width: 70px; text-align: center; }
        .cart-img { width: 70px; height: 70px; object-fit: cover; border-radius: 8px; }
    </style>
</head>

<div class="container my-5">
    <h2 class="fw-bold mb-4"><i class="bi bi-cart"></i> Giỏ hàng của bạn</h2>

    <%-- Thông báo thành công / thất bại --%>
    <c:set var="msg" value="${not empty requestScope.message ? requestScope.message : sessionScope.message}" />
    <c:if test="${not empty msg}">
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            ${msg}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    </c:if>

    <c:set var="err" value="${not empty requestScope.error ? requestScope.error : sessionScope.error}" />
    <c:if test="${not empty err}">
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            ${err}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    </c:if>

    <%-- Lấy đối tượng giỏ hàng --%>
    <c:set var="cart" value="${not empty requestScope.cart ? requestScope.cart : sessionScope.cart}" />

    <%-- Chỉ gọi thuộc tính `items` có sẵn trong Cart.java --%>
    <c:set var="itemList" value="${cart.items}" />

    <%-- Đếm số lượng phần tử --%>
    <c:set var="itemCount" value="${not empty itemList ? fn:length(itemList) : 0}" />

    <c:choose>
        <%-- TRƯỜNG HỢP 1: Giỏ hàng trống --%>
        <c:when test="${empty cart or itemCount == 0}">
            <div class="alert alert-info py-3 mb-4 fs-5">
                🛒 Giỏ hàng của bạn đang trống!
            </div>
            <a href="${pageContext.request.contextPath}/product" class="btn btn-primary fw-bold">
                ← Tiếp tục mua sắm
            </a>
        </c:when>

        <%-- TRƯỜNG HỢP 2: Giỏ hàng có sản phẩm --%>
        <c:otherwise>
            <div class="card shadow-sm">
                <div class="card-body">
                    <c:set var="calculatedTotal" value="0" />

                    <c:forEach items="${itemList}" var="item">
                        <%-- Đọc ID sản phẩm linh hoạt --%>
                        <c:set var="pId" value="${item.product.productId}" />
                        <c:if test="${empty pId}">
                            <c:set var="pId" value="${item.product.id}" />
                        </c:if>
                        
                        <%-- Đọc Đơn giá linh hoạt --%>
                        <c:set var="itemPrice" value="${item.price}" />
                        <c:if test="${empty itemPrice || itemPrice == 0}">
                            <c:set var="itemPrice" value="${item.product.price}" />
                        </c:if>

                        <%-- Tính thành tiền từng món --%>
                        <c:set var="itemSubtotal" value="${itemPrice * item.quantity}" />
                        <c:set var="calculatedTotal" value="${calculatedTotal + itemSubtotal}" />

                        <%-- Đọc Ảnh linh hoạt --%>
                        <c:set var="imgSrc" value="${not empty item.product.images ? item.product.images : item.product.image}" />

                        <div class="cart-item row align-items-center">
                            <%-- Ảnh + Tên sản phẩm --%>
                            <div class="col-md-4 d-flex align-items-center gap-3">
                                <c:choose>
                                    <c:when test="${not empty imgSrc && fn:startsWith(imgSrc, 'http')}">
                                        <img src="${imgSrc}" class="cart-img" alt="${item.product.productName}"/>
                                    </c:when>
                                    <c:when test="${not empty imgSrc}">
                                        <img src="${pageContext.request.contextPath}/image?fname=${imgSrc}" class="cart-img" alt="${item.product.productName}"/>
                                    </c:when>
                                    <c:otherwise>
                                        <img src="data:image/svg+xml;charset=UTF-8,%3Csvg%20width%3D%2270%22%20height%3D%2270%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22%23eee%22%2F%3E%3Ctext%20x%3D%2250%25%22%20y%3D%2250%25%22%20dominant-baseline%3D%22middle%22%20text-anchor%3D%22middle%22%20fill%3D%22%23aaa%22%20font-size%3D%2210%22%3ENo%20Image%3C%2Ftext%3E%3C%2Fsvg%3E" class="cart-img" alt="No Image"/>
                                    </c:otherwise>
                                </c:choose>
                                <div>
                                    <strong class="fs-6 text-dark d-block">${item.product.productName}</strong>
                                    <small class="text-muted">Mã SP: #${pId}</small>
                                </div>
                            </div>

                            <%-- Đơn giá --%>
                            <div class="col-md-2">
                                <span class="fw-semibold">
                                    <fmt:formatNumber value="${itemPrice}" type="number" groupingUsed="true" /> đ
                                </span>
                            </div>

                            <%-- Cập nhật số lượng --%>
                            <div class="col-md-2">
                                <form action="${pageContext.request.contextPath}/cart/update" method="post" class="d-inline">
                                    <input type="hidden" name="productId" value="${pId}">
                                    <input type="number" name="quantity" value="${item.quantity}" min="1" class="form-control quantity-input d-inline" onchange="this.form.submit()">
                                </form>
                            </div>

                            <%-- Thành tiền --%>
                            <div class="col-md-2 fw-bold text-danger">
                                <fmt:formatNumber value="${itemSubtotal}" type="number" groupingUsed="true" /> đ
                            </div>

                            <%-- Nút xóa --%>
                            <div class="col-md-2 text-end">
                                <a href="${pageContext.request.contextPath}/cart/remove?productId=${pId}" class="btn btn-outline-danger btn-sm" onclick="return confirm('Bạn có chắc muốn xóa sản phẩm này khỏi giỏ hàng?')">
                                    <i class="bi bi-trash"></i> Xóa
                                </a>
                            </div>
                        </div>
                    </c:forEach>

                    <%-- Thanh tổng tiền & Thanh toán --%>
                    <div class="row mt-4 pt-3 border-top align-items-center">
                        <div class="col-md-6">
                            <a href="${pageContext.request.contextPath}/cart/clear" class="btn btn-outline-danger" onclick="return confirm('Bạn có chắc muốn xóa toàn bộ giỏ hàng?')">
                                🗑️ Xóa tất cả
                            </a>
                            <a href="${pageContext.request.contextPath}/product" class="btn btn-outline-secondary ms-2">
                                ← Tiếp tục mua sắm
                            </a>
                        </div>
                        <div class="col-md-6 text-end">
                            <h4 class="fw-bold text-danger mb-3">
                                Tổng tiền: 
                                <fmt:formatNumber value="${not empty cart.totalAmount && cart.totalAmount > 0 ? cart.totalAmount : calculatedTotal}" type="number" groupingUsed="true" /> đ
                            </h4>
                            <a href="${pageContext.request.contextPath}/cart/checkout" class="btn btn-success btn-lg fw-bold px-4">
                                💳 Tiến hành thanh toán
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </c:otherwise>
    </c:choose>
</div>