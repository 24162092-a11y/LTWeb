<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Thanh toán</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
</head>
<body>
<%@ include file="/views/common/header.jsp" %>

<div class="container mt-4">
    <h2><i class="bi bi-credit-card"></i> Thanh toán</h2>

    <c:if test="${not empty sessionScope.error}">
        <div class="alert alert-danger">${sessionScope.error}</div>
        <% session.removeAttribute("error"); %>
    </c:if>

    <form action="${pageContext.request.contextPath}/order/create" method="post">
        <div class="card">
            <div class="card-body">
                <div class="mb-3">
                    <label class="form-label">Địa chỉ giao hàng</label>
                    <input type="text" class="form-control" name="shippingAddress" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Ghi chú</label>
                    <textarea class="form-control" name="note" rows="3"></textarea>
                </div>
                <button type="submit" class="btn btn-success">Xác nhận đặt hàng</button>
                <a href="${pageContext.request.contextPath}/cart" class="btn btn-secondary">Quay lại giỏ hàng</a>
            </div>
        </div>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>