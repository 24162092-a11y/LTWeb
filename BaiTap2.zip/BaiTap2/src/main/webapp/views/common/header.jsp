<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>

<!-- Header Nav -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm" style="position: relative; z-index: 1050;">
    <div class="container">
        <a class="navbar-brand fw-bold" href="${pageContext.request.contextPath}/">
            <i class="bi bi-shop"></i> ServiceMVC
        </a>
        
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" 
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <c:if test="${sessionScope.account != null}">
                    <li class="nav-item">
                        <a class="nav-link" href="${pageContext.request.contextPath}/admin/categories">
                            <i class="bi bi-grid"></i> Danh mục
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="${pageContext.request.contextPath}/admin/products">
                            <i class="bi bi-box-seam"></i> Sản phẩm
                        </a>
                    </li>
                </c:if>
            </ul>
            
            <ul class="navbar-nav ms-auto align-items-center">
                <c:choose>
                    <c:when test="${sessionScope.account == null}">
                        <li class="nav-item">
                            <a class="nav-link" href="${pageContext.request.contextPath}/login">
                                <i class="bi bi-box-arrow-in-right"></i> Đăng nhập
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="${pageContext.request.contextPath}/register">
                                <i class="bi bi-person-plus"></i> Đăng ký
                            </a>
                        </li>
                    </c:when>
                    <c:otherwise>
                        <!-- Giỏ hàng nếu là USER -->
                        <c:if test="${sessionScope.account.role == 'USER'}">
                            <li class="nav-item me-3">
                                <a class="nav-link position-relative py-0" href="${pageContext.request.contextPath}/cart">
                                    <i class="bi bi-cart3 fs-4"></i>
                                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style="font-size: 0.65rem;">
                                        0
                                    </span>
                                </a>
                            </li>
                        </c:if>
                        
                        <!-- Menu Dropdown Avatar -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle d-flex align-items-center py-0" href="#" id="userDropdown" 
                               role="button" data-bs-toggle="dropdown" data-bs-auto-close="true" aria-expanded="false">
                                <c:choose>
                                    <%-- TH 1: Có ảnh avatar --%>
                                    <c:when test="${not empty sessionScope.account.images}">
                                        <img src="${pageContext.request.contextPath}/image?fname=${sessionScope.account.images}" 
                                             alt="Avatar" class="rounded-circle border border-2 border-white shadow-sm" 
                                             style="width: 36px; height: 36px; object-fit: cover;"
                                             onerror="this.onerror=null; this.style.display='none'; if(this.nextElementSibling) this.nextElementSibling.style.display='flex';"/>
                                        
                                        <%-- Dự phòng nếu ảnh lỗi --%>
                                        <div class="rounded-circle bg-light text-primary align-items-center justify-content-center border border-2 border-white shadow-sm" 
                                             style="width: 36px; height: 36px; font-weight: bold; font-size: 15px; display: none;">
                                            <c:choose>
                                                <c:when test="${not empty sessionScope.account.fullname}">
                                                    ${fn:toUpperCase(fn:substring(sessionScope.account.fullname, 0, 1))}
                                                </c:when>
                                                <c:otherwise>
                                                    ${fn:toUpperCase(fn:substring(sessionScope.account.username, 0, 1))}
                                                </c:otherwise>
                                            </c:choose>
                                        </div>
                                    </c:when>
                                    
                                    <%-- TH 2: Chưa chọn avatar (Lấy chữ cái đầu) --%>
                                    <c:otherwise>
                                        <div class="rounded-circle bg-light text-primary d-flex align-items-center justify-content-center border border-2 border-white shadow-sm" 
                                             style="width: 36px; height: 36px; font-weight: bold; font-size: 15px;">
                                            <c:choose>
                                                <c:when test="${not empty sessionScope.account.fullname}">
                                                    ${fn:toUpperCase(fn:substring(sessionScope.account.fullname, 0, 1))}
                                                </c:when>
                                                <c:otherwise>
                                                    ${fn:toUpperCase(fn:substring(sessionScope.account.username, 0, 1))}
                                                </c:otherwise>
                                            </c:choose>
                                        </div>
                                    </c:otherwise>
                                </c:choose>
                            </a>
                            
                            <ul class="dropdown-menu dropdown-menu-end shadow border-0 mt-2" aria-labelledby="userDropdown">
                                <li>
                                    <div class="dropdown-item-text">
                                        <div class="fw-bold text-dark">${sessionScope.account.fullname}</div>
                                        <small class="text-muted">@${sessionScope.account.username}</small>
                                    </div>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <c:if test="${sessionScope.account.role == 'ADMIN'}">
                                    <li>
                                        <a class="dropdown-item" href="${pageContext.request.contextPath}/admin/products">
                                            <i class="bi bi-speedometer2 me-2"></i> Quản trị
                                        </a>
                                    </li>
                                </c:if>
                                <li>
                                    <a class="dropdown-item" href="${pageContext.request.contextPath}/user/profile">
                                        <i class="bi bi-person me-2"></i> Hồ sơ
                                    </a>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <a class="dropdown-item text-danger" href="${pageContext.request.contextPath}/logout">
                                        <i class="bi bi-box-arrow-right me-2"></i> Đăng xuất
                                    </a>
                                </li>
                            </ul>
                        </li>
                    </c:otherwise>
                </c:choose>
            </ul>
        </div>
    </div>
</nav>