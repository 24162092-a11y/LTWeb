<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng nhập - Shopping Web</title>
    
    <!-- Tắt SiteMesh Decorator cho riêng trang Login -->
    <meta name="decorator" content="none"/>
    
    <!-- Bootstrap 5 CSS & Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
    <style>
        body {
            background: linear-gradient(135deg, #4e73df, #224abe);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
        }
        .auth-card {
            background: #ffffff;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            padding: 40px 36px;
            width: 100%;
            max-width: 420px;
        }
        .brand-title {
            color: #224abe;
            font-size: 1.6rem;
            font-weight: 800;
            letter-spacing: 1px;
            text-transform: uppercase;
            margin-bottom: 4px;
        }
        .sub-title {
            color: #6c757d;
            font-size: 1rem;
            font-weight: 600;
            margin-bottom: 24px;
        }
        .form-label {
            font-weight: 600;
            color: #333;
            font-size: 0.9rem;
        }
        .form-control {
            border-radius: 0 8px 8px 0;
            padding: 10px 14px;
        }
        .input-group-text {
            border-radius: 8px 0 0 8px;
        }
        .form-control:focus {
            border-color: #4e73df;
            box-shadow: 0 0 0 0.25rem rgba(78, 115, 223, 0.25);
        }
        .btn-primary {
            background-color: #4e73df;
            border: none;
            border-radius: 8px;
            font-weight: 700;
            transition: all 0.2s ease;
        }
        .btn-primary:hover {
            background-color: #224abe;
            transform: translateY(-1px);
        }
        .auth-links a {
            color: #4e73df;
            text-decoration: none;
            font-size: 0.88rem;
            font-weight: 500;
        }
        .auth-links a:hover {
            color: #224abe;
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <div class="auth-card">
        <!-- Tiêu đề Thương hiệu & Đăng nhập -->
        <div class="text-center">
            <div class="brand-title">
                <i class="bi bi-cart4"></i> SHOPPING WEB
            </div>
            <div class="sub-title">Đăng nhập tài khoản</div>
        </div>

        <%-- Hiển thị thông báo thành công hoặc lỗi --%>
        <c:set var="msg" value="${not empty requestScope.message ? requestScope.message : sessionScope.message}" />
        <c:if test="${not empty msg}">
            <div class="alert alert-success alert-dismissible fade show py-2 text-center fs-6 mb-3" role="alert">
                ${msg}
                <button type="button" class="btn-close py-2" data-bs-dismiss="alert"></button>
            </div>
        </c:if>

        <c:set var="err" value="${not empty requestScope.error ? requestScope.error : sessionScope.error}" />
        <c:if test="${not empty err}">
            <div class="alert alert-danger alert-dismissible fade show py-2 text-center fs-6 mb-3" role="alert">
                ${err}
                <button type="button" class="btn-close py-2" data-bs-dismiss="alert"></button>
            </div>
        </c:if>

        <%-- Form Đăng nhập --%>
        <form action="${pageContext.request.contextPath}/login" method="post">
            <div class="mb-3">
                <label class="form-label">Tên đăng nhập</label>
                <div class="input-group">
                    <span class="input-group-text bg-light text-muted"><i class="bi bi-person"></i></span>
                    <input type="text" name="username" class="form-control" placeholder="Nhập tên đăng nhập..." required autocomplete="off"/>
                </div>
            </div>

            <div class="mb-4">
                <label class="form-label">Mật khẩu</label>
                <div class="input-group">
                    <span class="input-group-text bg-light text-muted"><i class="bi bi-lock"></i></span>
                    <input type="password" name="password" class="form-control" placeholder="Nhập mật khẩu..." required/>
                </div>
            </div>

            <button type="submit" class="btn btn-primary w-100 py-2">
                <i class="bi bi-box-arrow-in-right"></i> Đăng nhập
            </button>
        </form>

        <%-- Liên kết điều hướng --%>
        <div class="d-flex justify-content-between mt-4 pt-2 border-top auth-links">
            <a href="${pageContext.request.contextPath}/register"><i class="bi bi-person-plus"></i> Đăng ký tài khoản</a>
            <a href="${pageContext.request.contextPath}/forgot-password"><i class="bi bi-key"></i> Quên mật khẩu?</a>
        </div>
    </div>

    <!-- Bootstrap JS cho nút tắt thông báo alert -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>