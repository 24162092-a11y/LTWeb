<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Chi tiết đơn hàng</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
</head>
<body>
<%@ include file="/views/common/header.jsp" %>

<div class="container mt-4">
    <h2><i class="bi bi-receipt"></i> Chi tiết đơn hàng #${order.orderId}</h2>
    
    <div class="card mb-3">
        <div class="card-body">
            <p><strong>Ngày đặt:</strong> <fmt:formatDate value="${order.orderDate}" pattern="dd/MM/yyyy HH:mm"/></p>
            <p><strong>Trạng thái:</strong> 
                <c:choose>
                    <c:when test="${order.status == 'PENDING'}"><span class="badge bg-warning">Chờ xác nhận</span></c:when>
                    <c:when test="${order.status == 'CONFIRMED'}"><span class="badge bg-primary">Đã xác nhận</span></c:when>
                    <c:when test="${order.status == 'SHIPPED'}"><span class="badge bg-info">Đang giao</span></c:when>
                    <c:when test="${order.status == 'DELIVERED'}"><span class="badge bg-success">Đã giao</span></c:when>
                    <c:when test="${order.status == 'CANCELLED'}"><span class="badge bg-danger">Đã hủy</span></c:when>
                    <c:otherwise>${order.status}</c:otherwise>
                </c:choose>
            </p>
            <p><strong>Địa chỉ giao hàng:</strong> ${order.shippingAddress}</p>
            <p><strong>Ghi chú:</strong> ${order.note}</p>
            <p><strong>Tổng tiền:</strong> <fmt:formatNumber value="${order.totalAmount}" type="number" groupingUsed="true"/> đ</p>
        </div>
    </div>

    <h4>Danh sách sản phẩm</h4>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Sản phẩm</th>
                <th>Giá</th>
                <th>Số lượng</th>
                <th>Thành tiền</th>
            </tr>
        </thead>
        <tbody>
            <c:forEach items="${order.items}" var="item">
                <tr>
                    <td>${item.product.productName}</td>
                    <td><fmt:formatNumber value="${item.price}" type="number" groupingUsed="true"/> đ</td>
                    <td>${item.quantity}</td>
                    <td><fmt:formatNumber value="${item.price * item.quantity}" type="number" groupingUsed="true"/> đ</td>
                </tr>
            </c:forEach>
        </tbody>
    </table>

    <a href="${pageContext.request.contextPath}/order/history" class="btn btn-secondary">Quay lại</a>
</div>
</body>
</html>