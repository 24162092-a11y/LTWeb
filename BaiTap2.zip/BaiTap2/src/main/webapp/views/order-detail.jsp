<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>

<head>
    <title>Chi tiết đơn hàng #${order.orderId}</title>
</head>

<div class="container my-5" style="max-width: 900px;">
    <!-- Nút quay lại -->
    <div class="mb-3">
        <a href="${pageContext.request.contextPath}/order/history" class="btn btn-link text-decoration-none text-secondary p-0">
            <i class="bi bi-arrow-left me-1"></i> Quay lại lịch sử đơn hàng
        </a>
    </div>

    <!-- Card thông tin tổng quan đơn hàng -->
    <div class="card shadow-sm border-0 rounded-3 mb-4">
        <div class="card-header bg-primary text-white py-3 d-flex justify-content-between align-items-center">
            <h5 class="mb-0 fw-bold"><i class="bi bi-receipt me-2"></i>Chi tiết đơn hàng #${order.orderId}</h5>
            <div>
                <c:choose>
                    <c:when test="${order.status == 'PENDING'}"><span class="badge bg-warning text-dark px-3 py-2 rounded-pill">Chờ xác nhận</span></c:when>
                    <c:when test="${order.status == 'CONFIRMED'}"><span class="badge bg-info text-dark px-3 py-2 rounded-pill">Đã xác nhận</span></c:when>
                    <c:when test="${order.status == 'SHIPPED'}"><span class="badge bg-primary px-3 py-2 rounded-pill">Đang giao</span></c:when>
                    <c:when test="${order.status == 'DELIVERED'}"><span class="badge bg-success px-3 py-2 rounded-pill">Đã giao</span></c:when>
                    <c:when test="${order.status == 'CANCELLED'}"><span class="badge bg-danger px-3 py-2 rounded-pill">Đã hủy</span></c:when>
                    <c:otherwise><span class="badge bg-secondary px-3 py-2 rounded-pill">${order.status}</span></c:otherwise>
                </c:choose>
            </div>
        </div>
        <div class="card-body p-4">
            <div class="row g-3">
                <div class="col-md-6">
                    <p class="mb-2 text-muted"><strong>Ngày đặt:</strong> 
                        <span class="text-dark"><fmt:formatDate value="${order.orderDate}" pattern="dd/MM/yyyy HH:mm"/></span>
                    </p>
                    <p class="mb-2 text-muted"><strong>Địa chỉ giao hàng:</strong> 
                        <span class="text-dark">${empty order.shippingAddress ? 'Chưa cung cấp' : order.shippingAddress}</span>
                    </p>
                </div>
                <div class="col-md-6">
                    <p class="mb-2 text-muted"><strong>Ghi chú:</strong> 
                        <span class="text-dark">${empty order.note ? 'Không có' : order.note}</span>
                    </p>
                    <p class="mb-0 text-muted"><strong>Tổng thành tiền:</strong> 
                        <span class="fs-5 fw-bold text-danger ms-2">
                            <fmt:formatNumber value="${order.totalAmount}" type="number" groupingUsed="true"/> đ
                        </span>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <!-- Bảng sản phẩm -->
    <div class="card shadow-sm border-0 rounded-3">
        <div class="card-header bg-white py-3 border-bottom">
            <h6 class="mb-0 fw-bold text-dark"><i class="bi bi-box-seam me-2"></i>Danh sách sản phẩm</h6>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-4 py-3">Sản phẩm</th>
                            <th class="text-center py-3">Đơn giá</th>
                            <th class="text-center py-3">Số lượng</th>
                            <th class="text-end pe-4 py-3">Thành tiền</th>
                        </tr>
                    </thead>
                    <tbody>
                        <c:forEach items="${order.items}" var="item">
                            <tr>
                                <td class="ps-4">
                                    <div class="fw-bold text-dark">${item.product.productName}</div>
                                </td>
                                <td class="text-center">
                                    <fmt:formatNumber value="${item.price}" type="number" groupingUsed="true"/> đ
                                </td>
                                <td class="text-center fw-bold">${item.quantity}</td>
                                <td class="text-end pe-4 fw-bold text-danger">
                                    <fmt:formatNumber value="${item.price * item.quantity}" type="number" groupingUsed="true"/> đ
                                </td>
                            </tr>
                        </c:forEach>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>