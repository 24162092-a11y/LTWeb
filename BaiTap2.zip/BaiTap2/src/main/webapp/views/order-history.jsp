<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Lịch sử đơn hàng</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
</head>
<body>
<%@ include file="/views/common/header.jsp" %>

<div class="container mt-4">
    <h2><i class="bi bi-clock-history"></i> Lịch sử đơn hàng</h2>
    
    <c:if test="${not empty sessionScope.message}">
        <div class="alert alert-success">${sessionScope.message}</div>
        <% session.removeAttribute("message"); %>
    </c:if>

    <c:if test="${empty orders}">
        <div class="alert alert-info">Bạn chưa có đơn hàng nào.</div>
    </c:if>

    <c:if test="${not empty orders}">
        <table class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th>Mã đơn hàng</th>
                    <th>Ngày đặt</th>
                    <th>Tổng tiền</th>
                    <th>Trạng thái</th>
                    <th>Thao tác</th>
                </tr>
            </thead>
            <tbody>
                <c:forEach items="${orders}" var="o">
                    <tr>
                        <td>#${o.orderId}</td>
                        <td><fmt:formatDate value="${o.orderDate}" pattern="dd/MM/yyyy HH:mm"/></td>
                        <td><fmt:formatNumber value="${o.totalAmount}" type="number" groupingUsed="true"/> đ</td>
                        <td>
                            <c:choose>
                                <c:when test="${o.status == 'PENDING'}"><span class="badge bg-warning">Chờ xác nhận</span></c:when>
                                <c:when test="${o.status == 'CONFIRMED'}"><span class="badge bg-primary">Đã xác nhận</span></c:when>
                                <c:when test="${o.status == 'SHIPPED'}"><span class="badge bg-info">Đang giao</span></c:when>
                                <c:when test="${o.status == 'DELIVERED'}"><span class="badge bg-success">Đã giao</span></c:when>
                                <c:when test="${o.status == 'CANCELLED'}"><span class="badge bg-danger">Đã hủy</span></c:when>
                                <c:otherwise>${o.status}</c:otherwise>
                            </c:choose>
                        </td>
                        <td><a href="${pageContext.request.contextPath}/order/detail?id=${o.orderId}" class="btn btn-sm btn-primary">Chi tiết</a></td>
                    </tr>
                </c:forEach>
            </tbody>
        </table>
    </c:if>
</div>
</body>
</html>