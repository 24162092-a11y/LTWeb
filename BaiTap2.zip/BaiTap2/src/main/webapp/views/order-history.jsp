<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>

<head>
    <title>Lịch sử đơn hàng</title>
</head>

<div class="container my-5">
    <div class="card shadow-sm border-0 rounded-3">
        <div class="card-header bg-white py-3 border-bottom">
            <h4 class="mb-0 fw-bold text-primary">
                <i class="bi bi-clock-history me-2"></i>Lịch sử đơn hàng
            </h4>
        </div>
        <div class="card-body p-0">
            <c:if test="${not empty sessionScope.message}">
                <div class="alert alert-success m-3 alert-dismissible fade show" role="alert">
                    ${sessionScope.message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <% session.removeAttribute("message"); %>
            </c:if>

            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-4 py-3">Mã đơn hàng</th>
                            <th class="py-3">Ngày đặt</th>
                            <th class="py-3">Tổng tiền</th>
                            <th class="py-3">Trạng thái</th>
                            <th class="text-end pe-4 py-3">Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>
                        <c:choose>
                            <c:when test="${not empty orders}">
                                <c:forEach items="${orders}" var="o">
                                    <tr>
                                        <td class="ps-4 fw-bold text-primary">#${o.orderId}</td>
                                        <td>
                                            <i class="bi bi-calendar3 me-1 text-muted"></i>
                                            <fmt:formatDate value="${o.orderDate}" pattern="dd/MM/yyyy HH:mm"/>
                                        </td>
                                        <td class="fw-bold text-danger">
                                            <fmt:formatNumber value="${o.totalAmount}" type="number" groupingUsed="true"/> đ
                                        </td>
                                        <td>
                                            <c:choose>
                                                <c:when test="${o.status == 'PENDING'}"><span class="badge bg-warning text-dark px-3 py-2 rounded-pill">Chờ xác nhận</span></c:when>
                                                <c:when test="${o.status == 'CONFIRMED'}"><span class="badge bg-info text-dark px-3 py-2 rounded-pill">Đã xác nhận</span></c:when>
                                                <c:when test="${o.status == 'SHIPPED'}"><span class="badge bg-primary px-3 py-2 rounded-pill">Đang giao</span></c:when>
                                                <c:when test="${o.status == 'DELIVERED'}"><span class="badge bg-success px-3 py-2 rounded-pill">Đã giao</span></c:when>
                                                <c:when test="${o.status == 'CANCELLED'}"><span class="badge bg-danger px-3 py-2 rounded-pill">Đã hủy</span></c:when>
                                                <c:otherwise><span class="badge bg-secondary px-3 py-2 rounded-pill">${o.status}</span></c:otherwise>
                                            </c:choose>
                                        </td>
                                        <td class="text-end pe-4">
                                            <a href="${pageContext.request.contextPath}/order/detail?id=${o.orderId}" 
                                               class="btn btn-sm btn-outline-primary fw-semibold px-3 rounded-pill">
                                                <i class="bi bi-eye me-1"></i> Chi tiết
                                            </a>
                                        </td>
                                    </tr>
                                </c:forEach>
                            </c:when>
                            <c:otherwise>
                                <tr>
                                    <td colspan="5" class="text-center py-5 text-muted">
                                        <i class="bi bi-inbox fs-1 d-block mb-2 text-secondary"></i>
                                        Bạn chưa có đơn hàng nào!
                                    </td>
                                </tr>
                            </c:otherwise>
                        </c:choose>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>