<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<head>
    <title>Đặt hàng thành công</title>
</head>

<div class="container my-5 text-center" style="max-width: 500px;">
    <div class="card shadow-sm border-0 rounded-4 p-4">
        <div class="card-body">
            <!-- Icon dấu tick thành công -->
            <div class="mb-3">
                <div class="bg-success-subtle text-success d-inline-flex align-items-center justify-content-center rounded-circle" style="width: 80px; height: 80px;">
                    <i class="bi bi-check-lg display-4"></i>
                </div>
            </div>

            <h3 class="fw-bold text-dark mb-2">Đặt hàng thành công!</h3>
            <p class="text-muted mb-4">Cảm ơn bạn đã đặt hàng. Đơn hàng của bạn đã được xác nhận.</p>

            <c:if test="${not empty sessionScope.orderId}">
                <div class="bg-light p-3 rounded-3 mb-4">
                    <span class="text-muted small">Mã đơn hàng:</span>
                    <span class="fw-bold text-primary fs-5 ms-2">#${sessionScope.orderId}</span>
                </div>
            </c:if>

            <div class="d-grid gap-2">
                <a href="${pageContext.request.contextPath}/order/history" class="btn btn-primary py-2 fw-semibold rounded-pill">
                    <i class="bi bi-clock-history me-1"></i> Xem lịch sử đơn hàng
                </a>
                <a href="${pageContext.request.contextPath}/products" class="btn btn-outline-secondary py-2 fw-semibold rounded-pill">
                    <i class="bi bi-arrow-left me-1"></i> Tiếp tục mua sắm
                </a>
            </div>
        </div>
    </div>
</div>

<script>
    window.onload = function() {
        fetch('${pageContext.request.contextPath}/order/clear-session', {
            method: 'GET'
        }).catch(err => console.log('Clear session error:', err));
    };
</script>