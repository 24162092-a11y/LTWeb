<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đặt hàng thành công</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        body {
            background: #f5f5fa;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            margin: 0;
        }
        .success-container {
            text-align: center;
            background: white;
            border-radius: 20px;
            padding: 60px 50px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            max-width: 500px;
            width: 100%;
        }
        .success-icon {
            font-size: 80px;
            color: #28a745;
            margin-bottom: 20px;
        }
        .success-title {
            font-size: 28px;
            font-weight: 700;
            color: #333;
            margin-bottom: 10px;
        }
        .success-message {
            font-size: 16px;
            color: #666;
            margin-bottom: 30px;
        }
        .order-id {
            background: #f8f9fc;
            padding: 12px;
            border-radius: 10px;
            font-weight: 600;
            color: #4e73df;
            margin-bottom: 30px;
        }
        .btn-custom {
            padding: 10px 30px;
            border-radius: 30px;
            font-weight: 600;
        }
        .btn-primary-custom {
            background: #4e73df;
            color: white;
            border: none;
        }
        .btn-primary-custom:hover {
            background: #224abe;
            color: white;
        }
        .btn-outline-custom {
            border: 2px solid #4e73df;
            color: #4e73df;
            background: transparent;
        }
        .btn-outline-custom:hover {
            background: #4e73df;
            color: white;
        }
    </style>
</head>
<body>

<div class="success-container">
    <!-- Icon dấu tick -->
    <div class="success-icon">
        <i class="bi bi-check-circle-fill"></i>
    </div>

    <div class="success-title">Đặt hàng thành công!</div>
    <div class="success-message">
        Cảm ơn bạn đã đặt hàng. Đơn hàng của bạn đã được xác nhận.
    </div>

    <div class="order-id">
        <i class="bi bi-receipt"></i> Mã đơn hàng: #${sessionScope.orderId}
    </div>

    <div class="d-flex gap-3 justify-content-center flex-wrap">
        <a href="${pageContext.request.contextPath}/order/history" class="btn btn-primary-custom btn-custom">
            <i class="bi bi-clock-history"></i> Xem lịch sử đơn hàng
        </a>
        <a href="${pageContext.request.contextPath}/admin/products" class="btn btn-outline-custom btn-custom">
            <i class="bi bi-arrow-left"></i> Tiếp tục mua sắm
        </a>
    </div>
</div>

<!-- Script để tự động xóa session orderId sau khi load trang (tránh hiển thị lại) -->
<script>
    window.onload = function() {
        // Gửi request để xóa session attribute orderId sau khi hiển thị
        fetch('${pageContext.request.contextPath}/order/clear-session', {
            method: 'GET'
        }).catch(err => console.log('Clear session error:', err));
    };
</script>

</body>
</html>