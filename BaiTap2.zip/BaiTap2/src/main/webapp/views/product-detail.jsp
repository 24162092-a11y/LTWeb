<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>

<head>
    <title>${not empty product.productName ? product.productName : 'Chi tiết sản phẩm'}</title>
    <style>
        .product-detail-card {
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 4px 16px rgba(0,0,0,0.08);
            padding: 24px;
        }
        .detail-img {
            width: 100%;
            max-height: 400px;
            object-fit: contain;
            border-radius: 8px;
            background-color: #f8f9fa;
        }
        .detail-price {
            font-size: 1.75rem;
            font-weight: bold;
            color: #d9534f;
        }
    </style>
</head>

<div class="container my-5">
    <!-- Nút điều hướng phía trên -->
    <div class="mb-4 d-flex justify-content-between align-items-center">
        <a href="${pageContext.request.contextPath}/product" class="btn btn-outline-secondary btn-sm">
            ← Quay lại danh sách
        </a>

        <!-- Nút Thêm sản phẩm dành riêng cho ADMIN -->
        <c:if test="${sessionScope.account != null && (sessionScope.account.role == 'ADMIN' || sessionScope.account.roleid == 1 || sessionScope.account.roleId == 1)}">
            <div>
                <a href="${pageContext.request.contextPath}/admin/product/add" class="btn btn-primary btn-sm fw-bold">
                    ➕ Thêm sản phẩm mới
                </a>
                <a href="${pageContext.request.contextPath}/admin/products" class="btn btn-outline-primary btn-sm ms-2">
                    ⚙️ Danh sách quản trị
                </a>
            </div>
        </c:if>
    </div>

    <div class="product-detail-card">
        <div class="row g-4">
            <!-- Hình ảnh sản phẩm -->
            <div class="col-md-5">
                <c:choose>
                    <c:when test="${not empty product.images && fn:startsWith(product.images, 'http')}">
                        <img src="${product.images}" class="detail-img" alt="${product.productName}"/>
                    </c:when>
                    <c:when test="${not empty product.images}">
                        <img src="${pageContext.request.contextPath}/image?fname=${product.images}" class="detail-img" alt="${product.productName}"/>
                    </c:when>
                    <c:otherwise>
                        <img src="https://via.placeholder.com/400" class="detail-img" alt="No Image"/>
                    </c:otherwise>
                </c:choose>
            </div>

            <!-- Thông tin chi tiết -->
            <div class="col-md-7 d-flex flex-column justify-content-between">
                <div>
                    <!-- Tên Danh Mục -->
                    <c:if test="${not empty product.category}">
                        <span class="badge bg-primary mb-2">
                            ${not empty product.category.categoryname ? product.category.categoryname : product.category.categoryName}
                        </span>
                    </c:if>

                    <h2 class="fw-bold text-dark mb-3">${product.productName}</h2>
                    
                    <div class="detail-price mb-3">
                        <fmt:formatNumber value="${product.price}" type="number" groupingUsed="true"/> VNĐ
                    </div>

                    <hr/>

                    <h5 class="fw-bold mt-3">Mô tả sản phẩm:</h5>
                    <p class="text-muted fs-6" style="line-height: 1.6;">
                        <c:choose>
                            <c:when test="${not empty product.description}">
                                ${product.description}
                            </c:when>
                            <c:otherwise>
                                <i>Chưa có mô tả cho sản phẩm này.</i>
                            </c:otherwise>
                        </c:choose>
                    </p>
                </div>

                <!-- Thao tác phân quyền Admin / User -->
                <div class="pt-3 border-top d-flex gap-3">
                    <!-- Nút Thêm vào giỏ hàng -->
                    <a href="${pageContext.request.contextPath}/cart/add?productId=${not empty product.productId ? product.productId : product.id}" class="btn btn-success btn-lg px-4 fw-bold">
                        🛒 Thêm vào giỏ hàng
                    </a>

                    <!-- Nút Sửa/Xóa chỉ dành cho ADMIN -->
                    <c:if test="${sessionScope.account != null && (sessionScope.account.role == 'ADMIN' || sessionScope.account.roleid == 1 || sessionScope.account.roleId == 1)}">
                        <a href="${pageContext.request.contextPath}/admin/product/edit?id=${not empty product.productId ? product.productId : product.id}" class="btn btn-warning btn-lg px-4 fw-bold text-dark">
                            ✏️ Sửa sản phẩm
                        </a>
                        <a href="${pageContext.request.contextPath}/admin/product/delete?id=${not empty product.productId ? product.productId : product.id}" 
                           class="btn btn-danger btn-lg px-4 fw-bold"
                           onclick="return confirm('Bạn có chắc chắn muốn xóa sản phẩm này không?');">
                            🗑️ Xóa
                        </a>
                    </c:if>
                </div>
            </div>
        </div>
    </div>
</div>