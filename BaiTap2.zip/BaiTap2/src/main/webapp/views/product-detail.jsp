<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>

<!-- BẮT ID SẢN PHẨM AN TOÀN NHIỀU TẦNG -->
<c:set var="currentId" value="${product.productId}" />
<c:if test="${empty currentId}">
    <c:set var="currentId" value="${product.id}" />
</c:if>
<c:if test="${empty currentId}">
    <c:set var="currentId" value="${param.productId}" />
</c:if>
<c:if test="${empty currentId}">
    <c:set var="currentId" value="${param.id}" />
</c:if>

<head>
    <title>${not empty product.productName ? product.productName : 'Chi tiết sản phẩm'}</title>
    <style>
        .product-detail-card {
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 4px 16px rgba(0,0,0,0.08);
            padding: 24px;
        }
        .detail-img {
            width: 100%;
            max-height: 400px;
            object-fit: contain;
            border-radius: 8px;
            background-color: #f8f9fa;
        }
        .detail-price {
            font-size: 1.75rem;
            font-weight: bold;
            color: #d9534f;
        }
    </style>
</head>

<div class="container my-5">
    <!-- Nút điều hướng phía trên -->
    <div class="mb-4 d-flex justify-content-between align-items-center">
        <a href="${pageContext.request.contextPath}/product" class="btn btn-outline-secondary btn-sm">
            ← Quay lại danh sách
        </a>

        <!-- Nút Thêm sản phẩm dành riêng cho ADMIN -->
        <c:if test="${sessionScope.account != null && (sessionScope.account.role == 'ADMIN' || sessionScope.account.role == '1')}">
            <div>
                <a href="${pageContext.request.contextPath}/admin/product/add" class="btn btn-primary btn-sm fw-bold">
                    ➕ Thêm sản phẩm mới
                </a>
                <a href="${pageContext.request.contextPath}/admin/products" class="btn btn-outline-primary btn-sm ms-2">
                    ⚙️ Danh sách quản trị
                </a>
            </div>
        </c:if>
    </div>

    <div class="product-detail-card">
        <div class="row g-4">
            <!-- Hình ảnh sản phẩm -->
            <div class="col-md-5">
                <c:set var="imgSrc" value="${not empty product.images ? product.images : product.image}" />
                <c:choose>
                    <c:when test="${not empty imgSrc && fn:startsWith(imgSrc, 'http')}">
                        <img src="${imgSrc}" class="detail-img" alt="${product.productName}"/>
                    </c:when>
                    <c:when test="${not empty imgSrc}">
                        <img src="${pageContext.request.contextPath}/image?fname=${imgSrc}" class="detail-img" alt="${product.productName}"/>
                    </c:when>
                    <c:otherwise>
                        <img src="data:image/svg+xml;charset=UTF-8,%3Csvg%20width%3D%22400%22%20height%3D%22300%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%20400%20300%22%20preserveAspectRatio%3D%22none%22%3E%3Crect%20width%3D%22400%22%20height%3D%22300%22%20fill%3D%22%23eeeeee%22%3E%3C%2Frect%3E%3Ctext%20x%3D%2250%25%22%20y%3D%2250%25%22%20dominant-baseline%3D%22middle%22%20text-anchor%3D%22middle%22%20fill%3D%22%23aaa%22%20font-size%3D%2220%22%3ENo%20Image%3C%2Ftext%3E%3C%2Fsvg%3E" class="detail-img" alt="No Image"/>
                    </c:otherwise>
                </c:choose>
            </div>

            <!-- Thông tin chi tiết -->
            <div class="col-md-7 d-flex flex-column justify-content-between">
                <div>
                    <!-- Tên Danh Mục -->
                    <c:if test="${not empty product.category}">
                        <span class="badge bg-primary mb-2">
                            ${not empty product.category.categoryname ? product.category.categoryname : product.category.categoryName}
                        </span>
                    </c:if>

                    <h2 class="fw-bold text-dark mb-3">${product.productName}</h2>
                    
                    <div class="detail-price mb-3">
                        <fmt:formatNumber value="${product.price}" type="number" groupingUsed="true"/> VNĐ
                    </div>

                    <hr/>

                    <h5 class="fw-bold mt-3">Mô tả sản phẩm:</h5>
                    <p class="text-muted fs-6" style="line-height: 1.6;">
                        <c:choose>
                            <c:when test="${not empty product.description}">
                                ${product.description}
                            </c:when>
                            <c:otherwise>
                                <i>Chưa có mô tả cho sản phẩm này.</i>
                            </c:otherwise>
                        </c:choose>
                    </p>
                </div>

                <div class="pt-3 border-top d-flex gap-3 align-items-center">
                    <!-- SỬ DỤNG LINK TRỰC TIẾP CHỨA THAM SỐ LÊN URL TRÁNH NGUYÊN NHÂN FORM BỊ MẤT VALUE -->
                    <a href="${pageContext.request.contextPath}/cart/add?productId=${currentId}&id=${currentId}&quantity=1" 
                       class="btn btn-success btn-lg px-4 fw-bold">
                        🛒 Thêm vào giỏ hàng
                    </a>

                    <!-- Nút Sửa/Xóa dành riêng cho ADMIN -->
                    <c:if test="${sessionScope.account != null && (sessionScope.account.role == 'ADMIN' || sessionScope.account.role == '1')}">
                        <a href="${pageContext.request.contextPath}/admin/product/edit?id=${currentId}" class="btn btn-warning btn-lg px-4 fw-bold text-dark">
                            ✏️ Sửa sản phẩm
                        </a>
                        <a href="${pageContext.request.contextPath}/admin/product/delete?id=${currentId}" 
                           class="btn btn-danger btn-lg px-4 fw-bold"
                           onclick="return confirm('Bạn có chắc chắn muốn xóa sản phẩm này không?');">
                            🗑️ Xóa
                        </a>
                    </c:if>
                </div>
            </div>
        </div>
    </div>
</div>