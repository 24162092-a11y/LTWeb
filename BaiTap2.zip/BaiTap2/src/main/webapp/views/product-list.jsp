<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>

<head>
    <title>Danh sách Sản phẩm</title>
    <style>
        .product-grid { 
            display: grid; 
            grid-template-columns: repeat(3, 1fr); 
            gap: 20px; 
        }
        @media (max-width: 768px) {
            .product-grid {
                grid-template-columns: repeat(1, 1fr);
            }
        }
        .product-card { 
            border: 1px solid #e0e0e0; 
            border-radius: 12px;
            padding: 16px; 
            text-align: center; 
            background: #fff;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
            transition: transform 0.2s;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
        .product-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 6px 16px rgba(0,0,0,0.1);
        }
        .product-img {
            width: 100%;
            height: 180px;
            object-fit: cover;
            border-radius: 8px;
            margin-bottom: 12px;
        }
        .price-text {
            color: #d9534f;
            font-weight: bold;
            font-size: 1.1rem;
        }
        .btn-group-action {
            display: flex;
            gap: 6px;
            margin-top: 8px;
        }
    </style>
</head>

<div class="container my-4">
    <!-- TIÊU ĐỀ VÀ NÚT THÊM SẢN PHẨM -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold mb-0">🛍️ DANH SÁCH SẢN PHẨM</h2>
        
        <!-- Kiểm tra thuộc tính role chuẩn kiểu String từ Entity User -->
        <c:if test="${sessionScope.account != null && (sessionScope.account.role == 'ADMIN' || sessionScope.account.role == '1')}">
            <a href="${pageContext.request.contextPath}/admin/product/add" class="btn btn-primary fw-bold">
                ➕ Thêm sản phẩm mới
            </a>
        </c:if>
    </div>

    <!-- Thông báo lỗi/thành công (nếu có) -->
    <c:if test="${not empty sessionScope.error}">
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            ${sessionScope.error}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <% session.removeAttribute("error"); %>
    </c:if>
    <c:if test="${not empty sessionScope.message}">
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            ${sessionScope.message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <% session.removeAttribute("message"); %>
    </c:if>
    
    <!-- LƯỚI SẢN PHẨM -->
    <div class="product-grid">
        <c:forEach items="${productList}" var="p">
            <c:set var="currentId" value="${not empty p.productId ? p.productId : p.id}" />

            <div class="product-card">
                <div>
                    <!-- HÌNH ẢNH SẢN PHẨM -->
                    <c:choose>
                        <c:when test="${not empty p.images && fn:startsWith(p.images, 'http')}">
                            <img src="${p.images}" class="product-img" alt="${p.productName}"/>
                        </c:when>
                        <c:when test="${not empty p.images}">
                            <img src="${pageContext.request.contextPath}/image?fname=${p.images}" class="product-img" alt="${p.productName}"/>
                        </c:when>
                        <c:otherwise>
                            <img src="https://via.placeholder.com/150" class="product-img" alt="No Image"/>
                        </c:otherwise>
                    </c:choose>

                    <!-- TÊN & GIÁ SẢN PHẨM -->
                    <h5 class="fw-bold text-truncate" title="${p.productName}">${p.productName}</h5>
                    <p class="price-text mb-3">
                        <fmt:formatNumber value="${p.price}" type="number" groupingUsed="true"/> VNĐ
                    </p>
                </div>
                
                <!-- CÁC NÚT THAO TÁC -->
                <div>
                    <!-- Nút Xem chi tiết DÀNH CHO TẤT CẢ USER -->
                    <a href="${pageContext.request.contextPath}/product/detail?id=${currentId}" class="btn btn-outline-primary btn-sm w-100 fw-semibold">
                        🔍 Xem chi tiết
                    </a>

                    <!-- Nút Sửa & Xóa CHỈ HIỂN THỊ CHO ADMIN -->
                    <c:if test="${sessionScope.account != null && (sessionScope.account.role == 'ADMIN' || sessionScope.account.role == '1')}">
                        <div class="btn-group-action">
                            <a href="${pageContext.request.contextPath}/admin/product/edit?id=${currentId}" class="btn btn-warning btn-sm flex-fill fw-bold text-dark">
                                ✏️ Sửa
                            </a>
                            <a href="${pageContext.request.contextPath}/admin/product/delete?id=${currentId}" 
                               class="btn btn-danger btn-sm flex-fill fw-bold"
                               onclick="return confirm('Bạn có chắc chắn muốn xóa sản phẩm này?');">
                                🗑️ Xóa
                            </a>
                        </div>
                    </c:if>
                </div>
            </div>
        </c:forEach>
    </div>

    <!-- NẾU KHÔNG CÓ SẢN PHẨM NÀO -->
    <c:if test="${empty productList}">
        <div class="text-center py-5">
            <p class="text-muted fs-5">Chưa có sản phẩm nào để hiển thị.</p>
        </div>
    </c:if>

    <!-- THANH PHÂN TRANG -->
    <c:if test="${totalPages > 1}">
        <nav aria-label="Page navigation" class="mt-4">
            <ul class="pagination justify-content-center">
                <li class="page-item ${currentPage == 1 ? 'disabled' : ''}">
                    <a class="page-link" href="${pageContext.request.contextPath}/product?page=${currentPage - 1}">Trước</a>
                </li>

                <c:forEach begin="1" end="${totalPages}" var="i">
                    <li class="page-item ${currentPage == i ? 'active' : ''}">
                        <a class="page-link" href="${pageContext.request.contextPath}/product?page=${i}">${i}</a>
                    </li>
                </c:forEach>

                <li class="page-item ${currentPage == totalPages ? 'disabled' : ''}">
                    <a class="page-link" href="${pageContext.request.contextPath}/product?page=${currentPage + 1}">Sau</a>
                </li>
            </ul>
        </nav>
    </c:if>
</div>