<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<head>
    <title>Hồ sơ người dùng</title>
</head>

<div class="container my-5" style="max-width: 650px;">
    <div class="card shadow border-0">
        <div class="card-header bg-primary text-white text-center py-3">
            <h3 class="mb-0 fw-bold">HỒ SƠ NGƯỜI DÙNG</h3>
        </div>
        <div class="card-body p-4">

            <c:if test="${not empty message}">
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    ${message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            </c:if>
            <c:if test="${not empty error}">
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    ${error}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            </c:if>

            <div id="jsError" class="alert alert-danger d-none" role="alert"></div>

            <form action="${pageContext.request.contextPath}/user/profile" method="post" 
                  enctype="multipart/form-data" onsubmit="return validateProfileForm();">

                <div class="text-center mb-4">
                    <c:choose>
                        <c:when test="${not empty user.images}">
                            <img src="${pageContext.request.contextPath}/image?fname=${user.images}" 
                                 id="previewImg" class="rounded-circle border border-3 border-primary shadow-sm" 
                                 style="width: 140px; height: 140px; object-fit: cover;"
                                 onerror="this.onerror=null; this.src='https://via.placeholder.com/140';"/>
                        </c:when>
                        <c:otherwise>
                            <img src="https://via.placeholder.com/140" 
                                 id="previewImg" class="rounded-circle border border-3 shadow-sm" 
                                 style="width: 140px; height: 140px; object-fit: cover;" alt="Avatar mặc định"/>
                        </c:otherwise>
                    </c:choose>
                </div>

                <div class="mb-3">
                    <label for="imageFile" class="form-label fw-semibold">Đổi ảnh đại diện:</label>
                    <input type="file" class="form-control" id="imageFile" name="imageFile" 
                           accept="image/*" onchange="previewFile(this);">
                </div>

                <div class="mb-3">
                    <label for="fullname" class="form-label fw-semibold">Họ và tên <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="fullname" name="fullname" 
                           value="${user.fullname}" required>
                </div>

                <div class="mb-3">
                    <label for="phone" class="form-label fw-semibold">Số điện thoại</label>
                    <input type="text" class="form-control" id="phone" name="phone" 
                           value="${user.phone}" placeholder="Nhập số điện thoại (9-11 số)">
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold text-muted">Tên đăng nhập</label>
                        <input type="text" class="form-control bg-light" value="${user.username}" disabled readonly>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold text-muted">Vai trò</label>
                        <input type="text" class="form-control bg-light" value="${user.role}" disabled readonly>
                    </div>
                </div>

                <div class="mb-4">
                    <label class="form-label fw-semibold text-muted">Địa chỉ Email</label>
                    <input type="email" class="form-control bg-light" value="${user.email}" disabled readonly>
                </div>

                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary py-2 fw-bold shadow-sm">
                        CẬP NHẬT THÔNG TIN
                    </button>

                    <c:choose>
                        <c:when test="${sessionScope.account.roleid == 1}">
                            <a href="${pageContext.request.contextPath}/admin/products" class="btn btn-outline-secondary py-2 fw-semibold">
                                Quay lại trang quản lý sản phẩm
                            </a>
                        </c:when>
                        <c:otherwise>
                            <a href="${pageContext.request.contextPath}/products" class="btn btn-outline-secondary py-2 fw-semibold">
                                Quay lại trang sản phẩm
                            </a>
                        </c:otherwise>
                    </c:choose>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    // Preview ảnh đại diện khi chọn file mới
    function previewFile(input) {
        let file = input.files[0];
        if (file) {
            let reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById("previewImg").src = e.target.result;
            }
            reader.readAsDataURL(file);
        }
    }

    // JS Validation Client-side
    function validateProfileForm() {
        let fullname = document.getElementById("fullname").value.trim();
        let phone = document.getElementById("phone").value.trim();
        let fileInput = document.getElementById("imageFile");
        let errorDiv = document.getElementById("jsError");

        errorDiv.classList.add("d-none");
        errorDiv.innerText = "";

        if (fullname === "") {
            showJsError("Họ và tên không được để trống!");
            return false;
        }

        if (phone !== "") {
            let phonePattern = /^[0-9]{9,11}$/;
            if (!phonePattern.test(phone)) {
                showJsError("Số điện thoại không hợp lệ (phải từ 9 đến 11 chữ số)!");
                return false;
            }
        }

        if (fileInput.files.length > 0) {
            let fileName = fileInput.files[0].name;
            let ext = fileName.substring(fileName.lastIndexOf('.')).toLowerCase();
            if (!['.jpg', '.jpeg', '.png', '.gif', '.webp'].includes(ext)) {
                showJsError("Vui lòng chọn file ảnh hợp lệ (.jpg, .png, .gif, .webp)!");
                return false;
            }
        }

        return true;
    }

    function showJsError(msg) {
        let errorDiv = document.getElementById("jsError");
        errorDiv.innerText = msg;
        errorDiv.classList.remove("d-none");
    }
</script>