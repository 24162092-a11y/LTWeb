<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Kết quả Upload</title>
</head>
<body>
    <h3>Thông báo:</h3>
    <p style="color: blue;">${message}</p>
    
    <br/>
    <a href="${pageContext.request.contextPath}/upload.jsp">Quay lại trang Upload</a>
</body>
</html>