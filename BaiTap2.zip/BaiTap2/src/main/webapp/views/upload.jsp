<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Servlet Multipart Upload</title>
</head>
<body>
    <h2>Upload File bằng Servlet Multipart</h2>
    
    <form method="post" action="${pageContext.request.contextPath}/multiPartServlet" enctype="multipart/form-data">
        Chọn file: <input type="file" name="multiPartServlet" required />
        <br/><br/>
        <input type="submit" value="Upload" />
    </form>
</body>
</html>