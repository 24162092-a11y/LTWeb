<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Xác nhận OTP - Shopping Web</title>
    <!-- Bootstrap 5 CSS & Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
    <style>
        body {
            background: linear-gradient(135deg, #4e73df, #224abe);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
        }
        .auth-card {
            background: #ffffff;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            padding: 40px 36px;
            width: 100%;
            max-width: 420px;
        }
        .brand-title {
            color: #224abe;
            font-size: 1.6rem;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 4px;
        }
        .sub-title {
            color: #6c757d;
            font-size: 1rem;
            font-weight: 600;
            margin-bottom: 16px;
        }
        .otp-input {
            letter-spacing: 6px;
            font-size: 1.3rem;
            font-weight: 700;
            text-align: center;
            border-radius: 8px;
            padding: 10px;
        }
        .otp-input:focus {
            border-color: #4e73df;
            box-shadow: 0 0 0 0.25rem rgba(78, 115, 223, 0.25);
        }
        .btn-primary {
            background-color: #4e73df;
            border: none;
            border-radius: 8px;
            font-weight: 700;
            transition: all 0.2s ease;
        }
        .btn-primary:hover {
            background-color: #224abe;
            transform: translateY(-1px);
        }
        .auth-links a {
            color: #4e73df;
            text-decoration: none;
            font-size: 0.88rem;
            font-weight: 500;
        }
        .auth-links a:hover {
            color: #224abe;
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <div class="auth-card">
        <!-- Tiêu đề thương hiệu Web & Biểu tượng -->
        <div class="text-center">
            <div class="brand-title">
                <i class="bi bi-cart4"></i> SHOPPING WEB
            </div>
            <div class="sub-title">Xác nhận mã OTP</div>
        </div>

        <%-- Hiển thị thông báo Lỗi hoặc Thành công --%>
        <c:set var="msg" value="${not empty requestScope.message ? requestScope.message : sessionScope.message}" />
        <c:if test="${not empty msg}">
            <div class="alert alert-success alert-dismissible fade show py-2 text-center fs-6 mb-3" role="alert">
                ${msg}
                <button type="button" class="btn-close py-2" data-bs-dismiss="alert"></button>
            </div>
            <c:remove var="message" scope="session"/>
        </c:if>

        <c:set var="err" value="${not empty requestScope.error ? requestScope.error : sessionScope.error}" />
        <c:if test="${not empty err}">
            <div class="alert alert-danger alert-dismissible fade show py-2 text-center fs-6 mb-3" role="alert">
                ${err}
                <button type="button" class="btn-close py-2" data-bs-dismiss="alert"></button>
            </div>
            <c:remove var="error" scope="session"/>
        </c:if>

        <p class="text-muted text-center small mb-3">
            Mã OTP đã được gửi tới email:<br/>
            <strong class="text-dark">${not empty email ? email : sessionScope.OTP_EMAIL}</strong>
        </p>

        <!-- Form Nhập OTP -->
        <form action="${pageContext.request.contextPath}/verify-otp" method="post">
            <input type="hidden" name="email" value="${not empty email ? email : sessionScope.OTP_EMAIL}"/>

            <div class="mb-4">
                <div class="input-group">
                    <span class="input-group-text bg-light text-muted"><i class="bi bi-shield-lock"></i></span>
                    <input type="text" name="otp" class="form-control otp-input" required placeholder="Nhập mã OTP" maxlength="6" autocomplete="off"/>
                </div>
            </div>

            <button type="submit" class="btn btn-primary w-100 py-2 mb-3">
                <i class="bi bi-check-circle"></i> Xác nhận
            </button>
        </form>

        <!-- Liên kết điều hướng -->
        <div class="text-center pt-2 border-top auth-links">
            <a href="${pageContext.request.contextPath}/login"><i class="bi bi-arrow-left"></i> Quay lại đăng nhập</a>
        </div>
    </div>

    <!-- Bootstrap 5 JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>